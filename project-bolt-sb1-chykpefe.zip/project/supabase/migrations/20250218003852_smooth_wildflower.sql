-- Create color_settings table
CREATE TABLE IF NOT EXISTS color_settings (
  id integer PRIMARY KEY DEFAULT 1,
  primary_color text NOT NULL DEFAULT '#0066cc',
  primary_dark text NOT NULL DEFAULT '#004d99',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT single_config CHECK (id = 1)
);

-- Enable RLS
ALTER TABLE color_settings ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can read color settings"
  ON color_settings FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Only admin can modify color settings"
  ON color_settings FOR ALL
  TO authenticated
  USING (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br')
  WITH CHECK (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br');

-- Insert default settings
INSERT INTO color_settings (id, primary_color, primary_dark)
VALUES (1, '#0066cc', '#004d99')
ON CONFLICT (id) DO NOTHING;
