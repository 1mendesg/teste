/*
  # Fix Orders Table Structure

  1. Changes
    - Drop and recreate orders table with proper structure
    - Add proper foreign key relationships
    - Add better constraints and indexes
    - Update RLS policies

  2. Security
    - Enable RLS
    - Add policies for users and admin access
    - Ensure proper data access control
*/

-- Drop existing table if it exists
DROP TABLE IF EXISTS orders CASCADE;

-- Create orders table with proper structure
CREATE TABLE orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  total_price numeric NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  payment_status text DEFAULT 'pending',
  payment_id text,
  shipping_address jsonb,
  selected_shipping jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  admin_id uuid REFERENCES auth.users(id),
  CONSTRAINT valid_items_json CHECK (
    jsonb_typeof(items) = 'array'
  ),
  CONSTRAINT valid_shipping_address CHECK (
    shipping_address IS NULL OR (
      jsonb_typeof(shipping_address) = 'object' AND
      shipping_address ? 'street' AND
      shipping_address ? 'number' AND
      shipping_address ? 'neighborhood' AND
      shipping_address ? 'city' AND
      shipping_address ? 'state' AND
      shipping_address ? 'zip_code'
    )
  ),
  CONSTRAINT valid_selected_shipping CHECK (
    selected_shipping IS NULL OR (
      jsonb_typeof(selected_shipping) = 'object' AND
      selected_shipping ? 'name' AND
      selected_shipping ? 'price' AND
      selected_shipping ? 'company'
    )
  ),
  CONSTRAINT valid_status CHECK (
    status IN ('pending', 'processing', 'completed', 'cancelled')
  ),
  CONSTRAINT valid_payment_status CHECK (
    payment_status IN ('pending', 'approved', 'rejected', 'refunded')
  )
);

-- Enable RLS
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can insert their own orders"
  ON orders
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can read their own orders"
  ON orders
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = user_id OR 
    LOWER(auth.email()) = 'luciano@usualetiquetas.com.br'
  );

CREATE POLICY "Admin can update orders"
  ON orders
  FOR UPDATE
  TO authenticated
  USING (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br')
  WITH CHECK (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br');

-- Create indexes for better performance
CREATE INDEX orders_user_id_idx ON orders(user_id);
CREATE INDEX orders_admin_id_idx ON orders(admin_id);
CREATE INDEX orders_created_at_idx ON orders(created_at DESC);
CREATE INDEX orders_status_idx ON orders(status);
CREATE INDEX orders_payment_status_idx ON orders(payment_status);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_orders_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_orders_updated_at
  BEFORE UPDATE ON orders
  FOR EACH ROW
  EXECUTE FUNCTION update_orders_updated_at();