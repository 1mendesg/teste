-- Create simplified orders table
CREATE TABLE IF NOT EXISTS simple_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL,
  customer_name text NOT NULL,
  cpf_cnpj text NOT NULL,
  product_name text NOT NULL,
  quantity integer NOT NULL,
  address text NOT NULL,
  zip_code text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE simple_orders ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Anyone can insert orders"
  ON simple_orders
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can read their own orders"
  ON simple_orders
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Admin can manage all orders"
  ON simple_orders
  FOR ALL
  TO authenticated
  USING (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br')
  WITH CHECK (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br');

-- Create indexes for better performance
CREATE INDEX simple_orders_created_at_idx ON simple_orders(created_at DESC);
CREATE INDEX simple_orders_company_name_idx ON simple_orders(company_name);
CREATE INDEX simple_orders_cpf_cnpj_idx ON simple_orders(cpf_cnpj);

-- Create updated_at trigger
CREATE TRIGGER update_simple_orders_updated_at
  BEFORE UPDATE ON simple_orders
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();