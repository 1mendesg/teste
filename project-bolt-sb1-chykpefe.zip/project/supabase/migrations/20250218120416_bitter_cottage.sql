/*
  # Update categories table with image support
  
  1. Changes
    - Add image_url column to categories table
    - Add image_url column to solutions table if not exists
  
  2. Notes
    - Ensures backward compatibility
    - Maintains existing data
*/

-- Add image_url to categories if it doesn't exist
ALTER TABLE categories 
ADD COLUMN IF NOT EXISTS image_url text;

-- Ensure solutions has image_url
ALTER TABLE solutions 
ADD COLUMN IF NOT EXISTS image_url text;