import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Solutions } from './components/Solutions';
import { About } from './components/About';
import { HowItWorks } from './components/HowItWorks';
import { Testimonials } from './components/Testimonials';
import { ContactForm } from './components/ContactForm';
import { Footer } from './components/Footer';
import { WhatsAppPopup } from './components/WhatsAppPopup';
import { WelcomePopup } from './components/WelcomePopup';
import { CartPage } from './pages/CartPage';
import { CheckoutSuccessPage } from './pages/CheckoutSuccessPage';
import { ProfilePage } from './pages/ProfilePage';
import { OrdersPage } from './pages/OrdersPage';
import { LoginPage } from './pages/LoginPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { AdminProductsPage } from './pages/AdminProductsPage';
import { AdminNewProductPage } from './pages/AdminNewProductPage';
import { AdminImagesPage } from './pages/AdminImagesPage';
import { AdminOrdersPage } from './pages/AdminOrdersPage';
import { AdminSolutionsPage } from './pages/AdminSolutionsPage';
import { AdminShippingConfigPage } from './pages/AdminShippingConfigPage';
import { CategoryPage } from './pages/CategoryPage';
import { SolutionPage } from './pages/SolutionPage';
import { ScrollToTop } from './components/ScrollToTop';
import { supabase } from './lib/supabase';

function MainLayout() {
  const location = useLocation();
  const [showWelcome, setShowWelcome] = React.useState(false);

  React.useEffect(() => {
    if (location.state?.showWelcome) {
      setShowWelcome(true);
      window.history.replaceState({}, document.title);
    }
  }, [location]);

  // Load favicon
  React.useEffect(() => {
    const loadFavicon = async () => {
      try {
        const { data } = await supabase
          .from('site_images')
          .select('current_image')
          .eq('section', 'favicon')
          .single();

        if (data?.current_image) {
          const favicon = document.getElementById('favicon') as HTMLLinkElement;
          if (favicon) {
            favicon.href = data.current_image;
            favicon.type = data.current_image.endsWith('.ico') ? 'image/x-icon' : 'image/png';
          }
        }
      } catch (error) {
        console.error('Error loading favicon:', error);
      }
    };

    loadFavicon();
  }, []);

  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={
          <main>
            <Hero />
            <Solutions />
            <About />
            <HowItWorks />
            <Testimonials />
            <ContactForm />
          </main>
        } />
        <Route path="/solucoes/:id" element={<SolutionPage />} />
        <Route path="/produtos/:slug" element={<CategoryPage />} />
        <Route path="/perfil" element={<ProfilePage />} />
        <Route path="/pedidos" element={<OrdersPage />} />
      </Routes>
      <Footer />
      <WhatsAppPopup />
      <WelcomePopup isOpen={showWelcome} onClose={() => setShowWelcome(false)} />
    </>
  );
}

function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="min-h-screen bg-white">
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/admin" element={<AdminDashboardPage />} />
          <Route path="/admin/produtos" element={<AdminProductsPage />} />
          <Route path="/admin/produtos/novo" element={<AdminNewProductPage />} />
          <Route path="/admin/imagens" element={<AdminImagesPage />} />
          <Route path="/admin/pedidos" element={<AdminOrdersPage />} />
          <Route path="/admin/solucoes" element={<AdminSolutionsPage />} />
          <Route path="/admin/frete" element={<AdminShippingConfigPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/success" element={<CheckoutSuccessPage />} />
          <Route path="*" element={<MainLayout />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;