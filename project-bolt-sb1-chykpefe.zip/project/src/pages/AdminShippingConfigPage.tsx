import React from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { Package, Settings, Plus, Image, ArrowLeft, ShoppingBag, Truck, Trash2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { getCurrentUser } from '../lib/auth';

interface ShippingConfig {
  id: string;
  origin_cep: string;
  min_weight_kg: number;
  max_weight_kg: number;
  min_dimension_cm: number;
  max_dimension_cm: number;
  weight_multiplier: number;
  express_surcharge: number;
  created_at: string;
}

interface CepRange {
  id: string;
  start_cep: string;
  end_cep: string;
  base_price: number;
  weight_multiplier: number;
}

export function AdminShippingConfigPage() {
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = React.useState<boolean | null>(null);
  const [isLoading, setIsLoading] = React.useState(true);
  const [isSaving, setIsSaving] = React.useState(false);
  const [config, setConfig] = React.useState<ShippingConfig>({
    id: '1',
    origin_cep: '84130000',
    min_weight_kg: 0.3,
    max_weight_kg: 30,
    min_dimension_cm: 16,
    max_dimension_cm: 105,
    weight_multiplier: 1,
    express_surcharge: 12,
    created_at: new Date().toISOString()
  });
  const [cepRanges, setCepRanges] = React.useState<CepRange[]>([]);
  const [newRange, setNewRange] = React.useState<Omit<CepRange, 'id'>>({
    start_cep: '',
    end_cep: '',
    base_price: 0,
    weight_multiplier: 1
  });
  const [success, setSuccess] = React.useState('');
  const [error, setError] = React.useState('');

  React.useEffect(() => {
    checkAdminStatus();
    loadConfig();
    loadCepRanges();
  }, []);

  const checkAdminStatus = async () => {
    const user = await getCurrentUser();
    setIsAdmin(user?.email?.toLowerCase() === 'luciano@usualetiquetas.com.br');
  };

  const loadConfig = async () => {
    try {
      const { data, error } = await supabase
        .from('shipping_config')
        .select('*')
        .single();

      if (error) throw error;
      if (data) setConfig(data);
    } catch (error) {
      console.error('Error loading config:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadCepRanges = async () => {
    try {
      const { data, error } = await supabase
        .from('shipping_cep_ranges')
        .select('*')
        .order('start_cep', { ascending: true });

      if (error) throw error;
      if (data) setCepRanges(data);
    } catch (error) {
      console.error('Error loading CEP ranges:', error);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    setError('');
    setSuccess('');

    try {
      const { error } = await supabase
        .from('shipping_config')
        .upsert({
          id: config.id,
          origin_cep: config.origin_cep,
          min_weight_kg: config.min_weight_kg,
          max_weight_kg: config.max_weight_kg,
          min_dimension_cm: config.min_dimension_cm,
          max_dimension_cm: config.max_dimension_cm,
          weight_multiplier: config.weight_multiplier,
          express_surcharge: config.express_surcharge,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
      setSuccess('Configurações salvas com sucesso!');
    } catch (err) {
      console.error('Error saving config:', err);
      setError('Erro ao salvar as configurações. Por favor, tente novamente.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleAddCepRange = async () => {
    try {
      // Validate CEPs
      if (newRange.start_cep.length !== 8 || newRange.end_cep.length !== 8) {
        setError('CEPs devem ter 8 dígitos');
        return;
      }

      if (parseInt(newRange.start_cep) > parseInt(newRange.end_cep)) {
        setError('CEP inicial deve ser menor que o CEP final');
        return;
      }

      // Check for overlapping ranges
      const hasOverlap = cepRanges.some(range => {
        const start = parseInt(range.start_cep);
        const end = parseInt(range.end_cep);
        const newStart = parseInt(newRange.start_cep);
        const newEnd = parseInt(newRange.end_cep);
        return (newStart <= end && newEnd >= start);
      });

      if (hasOverlap) {
        setError('Existe sobreposição com outras faixas de CEP');
        return;
      }

      const { error } = await supabase
        .from('shipping_cep_ranges')
        .insert([newRange]);

      if (error) throw error;

      await loadCepRanges();
      setNewRange({
        start_cep: '',
        end_cep: '',
        base_price: 0,
        weight_multiplier: 1
      });
      setSuccess('Faixa de CEP adicionada com sucesso!');
    } catch (err) {
      console.error('Error adding CEP range:', err);
      setError('Erro ao adicionar faixa de CEP');
    }
  };

  const handleDeleteCepRange = async (id: string) => {
    try {
      const { error } = await supabase
        .from('shipping_cep_ranges')
        .delete()
        .eq('id', id);

      if (error) throw error;

      await loadCepRanges();
      setSuccess('Faixa de CEP removida com sucesso!');
    } catch (err) {
      console.error('Error deleting CEP range:', err);
      setError('Erro ao remover faixa de CEP');
    }
  };

  if (isAdmin === null) {
    return <div>Carregando...</div>;
  }

  if (isAdmin === false) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-md">
        <div className="container mx-auto px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/')}
                className="flex items-center text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Voltar ao site
              </button>
              <span className="text-xl font-semibold text-gray-800">
                Painel Administrativo
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/admin')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <Settings size={20} />
                <span>Configurações</span>
              </button>
              <button
                onClick={() => navigate('/admin/produtos')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <Package size={20} />
                <span>Produtos</span>
              </button>
              <button
                onClick={() => navigate('/admin/pedidos')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <ShoppingBag size={20} />
                <span>Pedidos</span>
              </button>
              <button
                onClick={() => navigate('/admin/produtos/novo')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <Plus size={20} />
                <span>Novo Produto</span>
              </button>
              <button
                onClick={() => navigate('/admin/imagens')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <Image size={20} />
                <span>Imagens</span>
              </button>
              <button
                onClick={() => navigate('/admin/frete')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-blue-50 text-blue-600"
              >
                <Truck size={20} />
                <span>Frete</span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-6 py-8">
        <div className="space-y-6">
          {/* General Settings */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-semibold mb-6">Configurações Gerais</h2>
            
            {isLoading ? (
              <div className="text-center py-4">Carregando configurações...</div>
            ) : (
              <div className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      CEP de Origem
                    </label>
                    <input
                      type="text"
                      maxLength={8}
                      value={config.origin_cep}
                      onChange={(e) => setConfig(prev => ({
                        ...prev,
                        origin_cep: e.target.value.replace(/\D/g, '')
                      }))}
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Multiplicador de Peso Padrão
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      min="1"
                      value={config.weight_multiplier}
                      onChange={(e) => setConfig(prev => ({
                        ...prev,
                        weight_multiplier: parseFloat(e.target.value)
                      }))}
                      className="w-full p-2 border rounded-lg"
                    />
                    <p className="text-sm text-gray-500 mt-1">
                      Aumento: {((config.weight_multiplier - 1) * 100).toFixed(0)}%
                    </p>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">Limites de Peso</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Peso Mínimo (kg)
                      </label>
                      <input
                        type="number"
                        step="0.1"
                        min="0.1"
                        value={config.min_weight_kg}
                        onChange={(e) => setConfig(prev => ({
                          ...prev,
                          min_weight_kg: parseFloat(e.target.value)
                        }))}
                        className="w-full p-2 border rounded-lg"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Peso Máximo (kg)
                      </label>
                      <input
                        type="number"
                        step="0.1"
                        min="0.1"
                        value={config.max_weight_kg}
                        onChange={(e) => setConfig(prev => ({
                          ...prev,
                          max_weight_kg: parseFloat(e.target.value)
                        }))}
                        className="w-full p-2 border rounded-lg"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">Limites de Dimensões</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Dimensão Mínima (cm)
                      </label>
                      <input
                        type="number"
                        min="1"
                        value={config.min_dimension_cm}
                        onChange={(e) => setConfig(prev => ({
                          ...prev,
                          min_dimension_cm: parseInt(e.target.value)
                        }))}
                        className="w-full p-2 border rounded-lg"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Dimensão Máxima (cm)
                      </label>
                      <input
                        type="number"
                        min="1"
                        value={config.max_dimension_cm}
                        onChange={(e) => setConfig(prev => ({
                          ...prev,
                          max_dimension_cm: parseInt(e.target.value)
                        }))}
                        className="w-full p-2 border rounded-lg"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">Configuração do Usuality Expresso</h3>
                  <div className="max-w-xs">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Valor Adicional (R$)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={config.express_surcharge}
                      onChange={(e) => setConfig(prev => ({
                        ...prev,
                        express_surcharge: parseFloat(e.target.value)
                      }))}
                      className="w-full p-2 border rounded-lg"
                    />
                    <p className="text-sm text-gray-500 mt-1">
                      Este valor será adicionado ao frete normal para entregas expressas
                    </p>
                  </div>
                </div>

                <div>
                  <button
                    onClick={handleSave}
                    disabled={isSaving}
                    className="btn bg-green-500 hover:bg-green-600 text-white px-8 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSaving ? 'Salvando...' : 'Salvar Configurações'}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* CEP Ranges */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-semibold mb-6">Faixas de CEP</h2>

            <div className="space-y-6">
              {/* Add new range form */}
              <div className="grid md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    CEP Inicial
                  </label>
                  <input
                    type="text"
                    maxLength={8}
                    value={newRange.start_cep}
                    onChange={(e) => setNewRange(prev => ({
                      ...prev,
                      start_cep: e.target.value.replace(/\D/g, '')
                    }))}
                    className="w-full p-2 border rounded-lg"
                    placeholder="00000000"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    CEP Final
                  </label>
                  <input
                    type="text"
                    maxLength={8}
                    value={newRange.end_cep}
                    onChange={(e) => setNewRange(prev => ({
                      ...prev,
                      end_cep: e.target.value.replace(/\D/g, '')
                    }))}
                    className="w-full p-2 border rounded-lg"
                    placeholder="99999999"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Preço Base
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={newRange.base_price}
                    onChange={(e) => setNewRange(prev => ({
                      ...prev,
                      base_price: parseFloat(e.target.value)
                    }))}
                    className="w-full p-2 border rounded-lg"
                    placeholder="0.00"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Multiplicador
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    min="1"
                    value={newRange.weight_multiplier}
                    onChange={(e) => setNewRange(prev => ({
                      ...prev,
                      weight_multiplier: parseFloat(e.target.value)
                    }))}
                    className="w-full p-2 border rounded-lg"
                    placeholder="1.0"
                  />
                </div>
              </div>

              <button
                onClick={handleAddCepRange}
                className="btn bg-blue-500 hover:bg-blue-600 text-white"
              >
                Adicionar Faixa
              </button>

              {/* Existing ranges table */}
              <div className="mt-6">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        CEP Inicial
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        CEP Final
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Preço Base
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Multiplicador
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Ações
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {cepRanges.map((range) => (
                      <tr key={range.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {range.start_cep}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {range.end_cep}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          R$ {range.base_price.toFixed(2)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {range.weight_multiplier}x
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <button
                            onClick={() => handleDeleteCepRange(range.id)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {error && (
            <div className="p-4 bg-red-50 text-red-700 rounded-lg">
              {error}
            </div>
          )}

          {success && (
            <div className="p-4 bg-green-50 text-green-700 rounded-lg">
              {success}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}