/*
  # Update products table schema

  1. Changes
    - Add solution_id column to products table
    - Add foreign key constraints to solutions table
    - Update RLS policies to include new columns
    - Drop old product_type column

  2. Security
    - Maintain existing RLS policies
    - Add foreign key constraints for data integrity
*/

-- Add new column
ALTER TABLE products
ADD COLUMN IF NOT EXISTS solution_id uuid REFERENCES solutions(id) ON DELETE CASCADE;

-- Drop old column
ALTER TABLE products
DROP COLUMN IF EXISTS product_type;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS products_solution_id_idx ON products(solution_id);

-- Update RLS policies
DROP POLICY IF EXISTS "Anyone can read products" ON products;
DROP POLICY IF EXISTS "Only admin can insert products" ON products;
DROP POLICY IF EXISTS "Only admin can update products" ON products;
DROP POLICY IF EXISTS "Only admin can delete products" ON products;

CREATE POLICY "Anyone can read products"
  ON products
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Only admin can insert products"
  ON products
  FOR INSERT
  TO authenticated
  WITH CHECK (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br');

CREATE POLICY "Only admin can update products"
  ON products
  FOR UPDATE
  TO authenticated
  USING (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br')
  WITH CHECK (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br');

CREATE POLICY "Only admin can delete products"
  ON products
  FOR DELETE
  TO authenticated
  USING (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br');