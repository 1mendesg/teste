import React from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { getCurrentUser } from '../lib/auth';
import { Clock, ShoppingBag } from 'lucide-react';

interface Order {
  id: string;
  items: Array<{
    id: string;
    name: string;
    price: number;
    quantity: number;
    size: string;
    image_url: string;
  }>;
  total_price: number;
  status: string;
  payment_status: string;
  shipping_address: {
    street: string;
    number: string;
    complement?: string;
    neighborhood: string;
    city: string;
    state: string;
    zip_code: string;
  };
  selected_shipping: {
    name: string;
    price: number;
    company: {
      name: string;
    };
  };
  created_at: string;
}

export function OrdersPage() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = React.useState(true);
  const [orders, setOrders] = React.useState<Order[]>([]);
  const [error, setError] = React.useState('');

  React.useEffect(() => {
    checkAuth();
    loadOrders();
  }, []);

  const checkAuth = async () => {
    const user = await getCurrentUser();
    if (!user) {
      navigate('/login');
    }
  };

  const loadOrders = async () => {
    try {
      const user = await getCurrentUser();
      if (!user) return;

      const { data, error: fetchError } = await supabase
        .from('orders')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;
      setOrders(data || []);
    } catch (err) {
      console.error('Error loading orders:', err);
      setError('Erro ao carregar pedidos. Por favor, tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const OrderCard = ({ order }: { order: Order }) => (
    <div className="bg-white rounded-lg shadow-md p-6 mb-4">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-semibold">
            Pedido #{order.id.slice(0, 8)}
          </h3>
          <p className="text-sm text-gray-500">
            {new Date(order.created_at).toLocaleString()}
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
            order.payment_status === 'approved' 
              ? 'bg-green-100 text-green-800' 
              : 'bg-yellow-100 text-yellow-800'
          }`}>
            {order.payment_status === 'approved' ? 'Pago' : 'Pendente'}
          </span>
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
            order.status === 'completed' 
              ? 'bg-green-100 text-green-800'
              : order.status === 'processing'
              ? 'bg-blue-100 text-blue-800'
              : 'bg-gray-100 text-gray-800'
          }`}>
            {order.status === 'completed' 
              ? 'Finalizado'
              : order.status === 'processing'
              ? 'Em Processamento'
              : 'Pendente'}
          </span>
        </div>
      </div>

      <div className="mb-6">
        <h4 className="font-medium mb-2">Produtos</h4>
        <div className="space-y-4">
          {order.items.map((item, index) => (
            <div key={index} className="flex items-center space-x-4">
              <img 
                src={item.image_url} 
                alt={item.name}
                className="w-16 h-16 object-cover rounded"
              />
              <div className="flex-1">
                <p className="font-medium">{item.name}</p>
                <p className="text-sm text-gray-600">Tamanho: {item.size}</p>
                <p className="text-sm text-gray-600">Quantidade: {item.quantity}</p>
                <p className="text-sm font-medium">R$ {item.price.toFixed(2)}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {order.shipping_address && (
        <div className="mb-6">
          <h4 className="font-medium mb-2">Endereço de Entrega</h4>
          <div className="text-sm text-gray-600">
            <p>
              {order.shipping_address.street}, {order.shipping_address.number}
              {order.shipping_address.complement && `, ${order.shipping_address.complement}`}
            </p>
            <p>{order.shipping_address.neighborhood}</p>
            <p>
              {order.shipping_address.city} - {order.shipping_address.state}
            </p>
            <p>CEP: {order.shipping_address.zip_code}</p>
          </div>
        </div>
      )}

      {order.selected_shipping && (
        <div className="border-t pt-4">
          <div className="flex justify-between items-center">
            <div className="text-sm text-gray-600">
              <p>Frete: {order.selected_shipping.name}</p>
              <p>Transportadora: {order.selected_shipping.company.name}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">
                Frete: R$ {order.selected_shipping.price.toFixed(2)}
              </p>
              <p className="text-lg font-bold text-green-600">
                Total: R$ {order.total_price.toFixed(2)}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  if (isLoading) {
    return (
      <div className="min-h-screen pt-32 pb-12 bg-gray-50">
        <div className="container">
          <div className="text-center">Carregando pedidos...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-32 pb-12 bg-gray-50">
      <div className="container max-w-4xl">
        <div className="flex items-center space-x-2 mb-8">
          <ShoppingBag className="w-6 h-6 text-gray-600" />
          <h1 className="text-3xl font-bold">Meus Pedidos</h1>
          <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded-full">
            {orders.length}
          </span>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-lg">
            {error}
          </div>
        )}

        {orders.length === 0 ? (
          <div className="bg-white rounded-lg shadow-lg p-6 text-center">
            <Clock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Você ainda não tem pedidos.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {orders.map(order => (
              <OrderCard key={order.id} order={order} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}