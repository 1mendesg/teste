import React from 'react';
import { useParams } from 'react-router-dom';
import { CustomLabelModal } from '../components/CustomLabelModal';
import { supabase } from '../lib/supabase';

interface Product {
  id: string;
  name: string;
  description: string;
  category_id: string;
  solution_id: string;
  dimensions: Array<{
    size: string;
    price: number;
    discount_price: number | null;
    stock: number;
  }>;
  min_quantity: number;
  image_url: string;
}

interface Category {
  id: string;
  title: string;
  description: string;
  slug: string;
  solution_id: string;
}

export function CategoryPage() {
  const { slug } = useParams<{ slug: string }>();
  const [isModalOpen, setIsModalOpen] = React.useState(false);
  const [products, setProducts] = React.useState<Product[]>([]);
  const [category, setCategory] = React.useState<Category | null>(null);
  const [selectedProduct, setSelectedProduct] = React.useState<Product | null>(null);
  const [isLoading, setIsLoading] = React.useState(true);

  React.useEffect(() => {
    window.scrollTo(0, 0);
    loadData();
  }, [slug]);

  const loadData = async () => {
    if (!slug) return;

    try {
      const { data: categoryData } = await supabase
        .from('categories')
        .select('*')
        .eq('slug', slug)
        .single();

      if (categoryData) {
        setCategory(categoryData);

        const { data: productsData } = await supabase
          .from('products')
          .select('*')
          .eq('category_id', categoryData.id)
          .order('created_at', { ascending: false });

        if (productsData) {
          setProducts(productsData);
        }
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen pt-32 pb-12 bg-white">
        <div className="container">
          <div className="text-center">Carregando produtos...</div>
        </div>
      </div>
    );
  }

  if (!category) {
    return (
      <div className="min-h-screen pt-32 pb-12 bg-white">
        <div className="container">
          <div className="text-center">Categoria não encontrada</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white pt-32 pb-12">
      <div className="container">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">{category.title}</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {category.description}
          </p>
        </div>

        {products.length === 0 ? (
          <div className="text-center text-gray-500">
            Nenhum produto encontrado nesta categoria.
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product) => (
              <div 
                key={product.id}
                className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
              >
                {/* Clique na imagem também abre o modal */}
                <div 
                  className="relative h-64 cursor-pointer"
                  onClick={() => {
                    setSelectedProduct(product);
                    setIsModalOpen(true);
                  }}
                >
                  <img 
                    src={product.image_url}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <h2 className="text-xl font-bold mb-2">{product.name}</h2>
                  <p className="text-gray-600 mb-4 line-clamp-2">{product.description}</p>
                  
                  <div className="space-y-2 mb-4">
                    <p className="text-sm text-gray-500">
                      Medidas disponíveis:
                    </p>
                    <div className="grid grid-cols-2 gap-2">
                      {product.dimensions.map((dim) => (
                        <div 
                          key={dim.size}
                          className="text-sm bg-gray-50 p-2 rounded"
                        >
                          <span className="font-medium">{dim.size}</span>
                          <br />
                          {dim.discount_price ? (
                            <div>
                              <span className="line-through text-gray-500">R$ {dim.price.toFixed(2)}</span>
                              <span className="text-green-600 ml-2">R$ {dim.discount_price.toFixed(2)}</span>
                            </div>
                          ) : (
                            <span>R$ {dim.price.toFixed(2)}</span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="text-sm text-gray-500 mb-4">
                    Quantidade mínima: {product.min_quantity} unidades
                  </div>

                  <button 
                    className="w-full btn bg-green-500 hover:bg-green-600 text-white"
                    onClick={() => {
                      setSelectedProduct(product);
                      setIsModalOpen(true);
                    }}
                  >
                    Comprar Agora
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {selectedProduct && (
          <CustomLabelModal 
            isOpen={isModalOpen}
            onClose={() => {
              setIsModalOpen(false);
              setSelectedProduct(null);
            }}
            product={selectedProduct}
          />
        )}
      </div>
    </div>
  );
}
