/*
  # Fix orders table relationships

  1. Changes
    - Drop and recreate orders table with proper foreign key relationships
    - Add missing columns for shipping and payment
    - Add proper indexes for better performance
    - Update RLS policies

  2. Security
    - Enable RLS
    - Add policies for users and admin access
*/

-- Drop existing table if it exists
DROP TABLE IF EXISTS orders CASCADE;

-- Create orders table with proper structure
CREATE TABLE orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  total_price numeric NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  payment_status text,
  payment_id text,
  shipping_address jsonb,
  selected_shipping jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can insert their own orders"
  ON orders
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can read their own orders"
  ON orders
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = user_id OR 
    auth.email() = 'luciano@usualetiquetas.com.br'
  );

CREATE POLICY "Admin can update orders"
  ON orders
  FOR UPDATE
  TO authenticated
  USING (auth.email() = 'luciano@usualetiquetas.com.br')
  WITH CHECK (auth.email() = 'luciano@usualetiquetas.com.br');

-- Create indexes for better performance
CREATE INDEX orders_user_id_idx ON orders(user_id);
CREATE INDEX orders_created_at_idx ON orders(created_at DESC);
CREATE INDEX orders_status_idx ON orders(status);
CREATE INDEX orders_payment_status_idx ON orders(payment_status);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_orders_updated_at
  BEFORE UPDATE ON orders
  FOR EACH ROW
  EXECUTE PROCEDURE update_updated_at_column();