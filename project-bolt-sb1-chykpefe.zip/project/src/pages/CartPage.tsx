import React from 'react';
import { useCart } from '../lib/cart';
import { Trash2, ArrowLeft, ShoppingBag, Truck, Store } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPreference } from '../lib/mercadopago';
import { calculateShipping } from '../lib/melhorEnvio';
import { supabase } from '../lib/supabase';

export function CartPage() {
  const { items, removeItem, updateQuantity, total, clearCart } = useCart();
  const [isProcessing, setIsProcessing] = React.useState(false);
  const [error, setError] = React.useState('');
  const [zipCode, setZipCode] = React.useState('');
  const [shippingOptions, setShippingOptions] = React.useState<any[]>([]);
  const [selectedShipping, setSelectedShipping] = React.useState<any>(null);
  const [isCalculatingShipping, setIsCalculatingShipping] = React.useState(false);

  const handleCheckout = async () => {
    if (!selectedShipping) {
      setError('Por favor, selecione uma opção de frete antes de continuar.');
      return;
    }

    try {
      setIsProcessing(true);
      setError('');
      const checkoutUrl = await createPreference(items, selectedShipping.price);
      window.location.href = checkoutUrl;
    } catch (error) {
      console.error('Error processing checkout:', error);
      setError('Erro ao processar o pagamento. Por favor, tente novamente.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCalculateShipping = async () => {
    if (!zipCode || zipCode.length !== 8) {
      setError('Por favor, insira um CEP válido');
      return;
    }

    setIsCalculatingShipping(true);
    setError('');
    setShippingOptions([]);

    try {
      // Get products with shipping info
      const productsData = await Promise.all(
        items.map(async (item) => {
          const { data: product } = await supabase
            .from('products')
            .select('weight_kg')
            .eq('id', item.id)
            .single();

          if (!product) {
            throw new Error(`Produto não encontrado: ${item.id}`);
          }

          return {
            weight_kg: product.weight_kg * item.quantity,
            quantity: item.quantity
          };
        })
      );

      const options = await calculateShipping(productsData, zipCode);
      setShippingOptions(options);
      setSelectedShipping(null); // Reset selection when new options are loaded
    } catch (err: any) {
      console.error('Error calculating shipping:', err);
      setError(err.message || 'Erro ao calcular o frete. Por favor, tente novamente.');
      setShippingOptions([]);
    } finally {
      setIsCalculatingShipping(false);
    }
  };

  React.useEffect(() => {
    // Load initial shipping options (store pickup)
    const loadInitialOptions = async () => {
      try {
        const options = await calculateShipping([], '00000000');
        setShippingOptions(options.filter(opt => opt.id === 'pickup'));
      } catch (error) {
        console.error('Error loading initial shipping options:', error);
      }
    };

    loadInitialOptions();
  }, []);

  if (items.length === 0) {
    return (
      <div className="min-h-screen pt-32 pb-12 bg-gray-50">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center">
            <ShoppingBag className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold mb-2">Seu carrinho está vazio</h2>
            <p className="text-gray-600 mb-6">
              Adicione produtos ao seu carrinho para continuar comprando.
            </p>
            <Link
              to="/"
              className="inline-flex items-center text-blue-600 hover:text-blue-800"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar às compras
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const finalTotal = selectedShipping 
    ? total() + selectedShipping.price 
    : total();

  return (
    <div className="min-h-screen pt-32 pb-12 bg-gray-50">
      <div className="container max-w-4xl mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">Carrinho de Compras</h1>
          <button
            onClick={clearCart}
            className="text-red-600 hover:text-red-800 flex items-center"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Limpar Carrinho
          </button>
        </div>

        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <div className="p-6 space-y-6">
            {items.map((item) => (
              <div
                key={`${item.id}-${item.size}`}
                className="flex items-center space-x-4 py-4 border-b last:border-0"
              >
                <img
                  src={item.image_url}
                  alt={item.name}
                  className="w-24 h-24 object-cover rounded-lg"
                />
                <div className="flex-1">
                  <h3 className="text-lg font-semibold">{item.name}</h3>
                  <p className="text-gray-600">Tamanho: {item.size}</p>
                  <p className="text-gray-600">
                    Preço: R$ {item.price.toFixed(2)}
                  </p>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() =>
                        updateQuantity(item.id, item.size, Math.max(1, item.quantity - 1))
                      }
                      className="w-8 h-8 flex items-center justify-center border rounded-lg"
                    >
                      -
                    </button>
                    <span className="w-12 text-center">{item.quantity}</span>
                    <button
                      onClick={() =>
                        updateQuantity(item.id, item.size, item.quantity + 1)
                      }
                      className="w-8 h-8 flex items-center justify-center border rounded-lg"
                    >
                      +
                    </button>
                  </div>
                  <button
                    onClick={() => removeItem(item.id, item.size)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Shipping Calculator */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex items-center space-x-2 mb-4">
            <Truck className="w-5 h-5 text-gray-600" />
            <h2 className="text-xl font-semibold">Calcular Frete</h2>
          </div>

          <div className="flex space-x-4 mb-6">
            <div className="flex-1">
              <input
                type="text"
                placeholder="Digite seu CEP"
                value={zipCode}
                onChange={(e) => setZipCode(e.target.value.replace(/\D/g, ''))}
                maxLength={8}
                className="w-full p-2 border rounded-lg"
              />
            </div>
            <button
              onClick={handleCalculateShipping}
              disabled={isCalculatingShipping || !zipCode || zipCode.length !== 8}
              className="btn bg-blue-500 hover:bg-blue-600 text-white disabled:opacity-50"
            >
              {isCalculatingShipping ? 'Calculando...' : 'Calcular'}
            </button>
          </div>

          {error && (
            <div className="p-4 bg-red-50 text-red-700 rounded-lg mb-4">
              {error}
            </div>
          )}

          {shippingOptions.length > 0 && (
            <div className="space-y-4">
              {shippingOptions.map((option) => (
                <label
                  key={option.id}
                  className={`flex items-center justify-between p-4 border rounded-lg cursor-pointer transition-colors ${
                    selectedShipping?.id === option.id
                      ? 'border-blue-500 bg-blue-50'
                      : 'hover:border-gray-400'
                  }`}
                >
                  <div className="flex items-center space-x-4">
                    <input
                      type="radio"
                      name="shipping"
                      checked={selectedShipping?.id === option.id}
                      onChange={() => setSelectedShipping(option)}
                      className="w-4 h-4 text-blue-600"
                    />
                    <div>
                      <div className="flex items-center space-x-2">
                        {option.id === 'pickup' ? (
                          <Store className="w-4 h-4 text-green-600" />
                        ) : (
                          <Truck className="w-4 h-4 text-blue-600" />
                        )}
                        <p className="font-medium">{option.company.name}</p>
                      </div>
                      <p className="text-sm text-gray-600">
                        {option.id === 'pickup' ? (
                          <>
                            Retirada em até 24h
                            <br />
                            <span className="text-xs">{option.address}</span>
                          </>
                        ) : (
                          `Entrega em até ${option.delivery_time} dias úteis`
                        )}
                      </p>
                    </div>
                  </div>
                  <span className="font-semibold">
                    {option.price === 0 ? 'Grátis' : `R$ ${option.price.toFixed(2)}`}
                  </span>
                </label>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="space-y-4 mb-6">
            <div className="flex justify-between items-center text-lg">
              <span>Subtotal:</span>
              <span>R$ {total().toFixed(2)}</span>
            </div>
            {selectedShipping && (
              <div className="flex justify-between items-center text-lg">
                <span>Frete:</span>
                <span>{selectedShipping.price === 0 ? 'Grátis' : `R$ ${selectedShipping.price.toFixed(2)}`}</span>
              </div>
            )}
            <div className="flex justify-between items-center text-xl font-bold border-t pt-4">
              <span>Total:</span>
              <span>R$ {finalTotal.toFixed(2)}</span>
            </div>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-lg">
              {error}
            </div>
          )}

          <div className="flex space-x-4">
            <Link
              to="/"
              className="flex-1 btn btn-outline flex items-center justify-center"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Continuar Comprando
            </Link>
            <button
              onClick={handleCheckout}
              disabled={isProcessing || !selectedShipping}
              className="flex-1 btn bg-green-500 hover:bg-green-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? 'Processando...' : 'Finalizar Compra'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}