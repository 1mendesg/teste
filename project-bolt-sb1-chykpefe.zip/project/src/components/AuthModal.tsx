import React from 'react';
import { useNavigate } from 'react-router-dom';
import { X } from 'lucide-react';
import { signIn, signUp } from '../lib/auth';
import { supabase } from '../lib/supabase';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

interface Address {
  logradouro: string;
  bairro: string;
  localidade: string;
  uf: string;
}

export function AuthModal({ isOpen, onClose, onSuccess }: AuthModalProps) {
  const navigate = useNavigate();
  const [isLogin, setIsLogin] = React.useState(false);
  const [step, setStep] = React.useState(1);
  const [formData, setFormData] = React.useState({
    email: '',
    password: '',
    confirmPassword: '',
    fullName: '',
    phone: '',
    company: '',
    cep: '',
    address: '',
    number: '',
    complement: '',
    neighborhood: '',
    city: '',
    state: '',
  });
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [error, setError] = React.useState('');
  const [isLoadingCep, setIsLoadingCep] = React.useState(false);

  if (!isOpen) return null;

  const handleCepBlur = async () => {
    if (formData.cep.length === 8) {
      setIsLoadingCep(true);
      try {
        const response = await fetch(`https://viacep.com.br/ws/${formData.cep}/json/`);
        const data: Address = await response.json();
        
        if (!data.erro) {
          setFormData(prev => ({
            ...prev,
            address: data.logradouro,
            neighborhood: data.bairro,
            city: data.localidade,
            state: data.uf
          }));
        }
      } catch (err) {
        console.error('Error fetching CEP:', err);
      } finally {
        setIsLoadingCep(false);
      }
    }
  };

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      setError('As senhas não coincidem');
      return;
    }
    setError('');
    setStep(2);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);

    try {
      if (isLogin) {
        const { error } = await signIn(formData.email, formData.password);
        if (error) throw error;
        
        // Check if user is admin
        if (formData.email.toLowerCase() === 'luciano@usualetiquetas.com.br') {
          onSuccess();
          onClose();
          navigate('/admin');
        } else {
          onSuccess();
          onClose();
          navigate('/');
        }
      } else {
        // Sign up flow
        const { data: authData, error: signUpError } = await signUp(formData.email, formData.password);
        if (signUpError) throw signUpError;

        if (authData.user) {
          // Create user profile
          const { error: profileError } = await supabase
            .from('user_profiles')
            .insert({
              user_id: authData.user.id,
              full_name: formData.fullName,
              phone: formData.phone,
              company_name: formData.company,
              address: `${formData.address}, ${formData.number}${formData.complement ? ` - ${formData.complement}` : ''}`,
              neighborhood: formData.neighborhood,
              city: formData.city,
              state: formData.state,
              zip_code: formData.cep
            })
            .select()
            .single();

          if (profileError) throw profileError;

          onSuccess();
          onClose();
          navigate('/', { 
            state: { 
              showWelcome: true
            }
          });
        }
      }
    } catch (err: any) {
      console.error('Auth error:', err);
      setError(err.message || 'Erro na autenticação. Por favor, tente novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSearchCep = () => {
    window.open('https://buscacepinter.correios.com.br/app/endereco/index.php', '_blank');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-md w-full">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">
              {isLogin ? 'Login' : 'Criar Conta'}
            </h2>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700"
            >
              <X size={24} />
            </button>
          </div>

          {isLogin ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  E-mail
                </label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, email: e.target.value }))
                  }
                  className="w-full p-2 border rounded-lg"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Senha
                </label>
                <input
                  type="password"
                  required
                  value={formData.password}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, password: e.target.value }))
                  }
                  className="w-full p-2 border rounded-lg"
                />
              </div>

              {error && (
                <div className="p-4 bg-red-50 text-red-700 rounded-lg">{error}</div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full btn bg-green-500 hover:bg-green-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? 'Processando...' : 'Entrar'}
              </button>
            </form>
          ) : (
            <form onSubmit={step === 1 ? handleNextStep : handleSubmit} className="space-y-4">
              {step === 1 ? (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Nome Completo
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.fullName}
                      onChange={(e) =>
                        setFormData((prev) => ({ ...prev, fullName: e.target.value }))
                      }
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Empresa
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.company}
                      onChange={(e) =>
                        setFormData((prev) => ({ ...prev, company: e.target.value }))
                      }
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Telefone
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData((prev) => ({ ...prev, phone: e.target.value }))
                      }
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      E-mail
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) =>
                        setFormData((prev) => ({ ...prev, email: e.target.value }))
                      }
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Senha
                    </label>
                    <input
                      type="password"
                      required
                      value={formData.password}
                      onChange={(e) =>
                        setFormData((prev) => ({ ...prev, password: e.target.value }))
                      }
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Confirmar Senha
                    </label>
                    <input
                      type="password"
                      required
                      value={formData.confirmPassword}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          confirmPassword: e.target.value,
                        }))
                      }
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>
                </>
              ) : (
                <>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        CEP
                      </label>
                      <input
                        type="text"
                        required
                        maxLength={8}
                        value={formData.cep}
                        onChange={(e) =>
                          setFormData((prev) => ({ ...prev, cep: e.target.value.replace(/\D/g, '') }))
                        }
                        onBlur={handleCepBlur}
                        className="w-full p-2 border rounded-lg"
                      />
                    </div>
                    <div className="flex items-end">
                      <button
                        type="button"
                        onClick={handleSearchCep}
                        className="w-full p-2 text-sm text-blue-600 hover:text-blue-800"
                      >
                        Não sei meu CEP
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Endereço
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.address}
                      onChange={(e) =>
                        setFormData((prev) => ({ ...prev, address: e.target.value }))
                      }
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Número
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.number}
                        onChange={(e) =>
                          setFormData((prev) => ({ ...prev, number: e.target.value }))
                        }
                        className="w-full p-2 border rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Complemento
                      </label>
                      <input
                        type="text"
                        value={formData.complement}
                        onChange={(e) =>
                          setFormData((prev) => ({ ...prev, complement: e.target.value }))
                        }
                        className="w-full p-2 border rounded-lg"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Bairro
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.neighborhood}
                      onChange={(e) =>
                        setFormData((prev) => ({ ...prev, neighborhood: e.target.value }))
                      }
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Cidade
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.city}
                        onChange={(e) =>
                          setFormData((prev) => ({ ...prev, city: e.target.value }))
                        }
                        className="w-full p-2 border rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Estado
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.state}
                        onChange={(e) =>
                          setFormData((prev) => ({ ...prev, state: e.target.value }))
                        }
                        className="w-full p-2 border rounded-lg"
                      />
                    </div>
                  </div>
                </>
              )}

              {error && (
                <div className="p-4 bg-red-50 text-red-700 rounded-lg">{error}</div>
              )}

              <div className="flex space-x-4">
                {step === 2 && (
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="w-full btn btn-outline"
                  >
                    Voltar
                  </button>
                )}
                <button
                  type="submit"
                  disabled={isSubmitting || isLoadingCep}
                  className="w-full btn bg-green-500 hover:bg-green-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting 
                    ? 'Processando...' 
                    : isLoadingCep
                    ? 'Carregando CEP...'
                    : step === 1 
                    ? 'Próximo' 
                    : 'Criar Conta'}
                </button>
              </div>
            </form>
          )}

          <button
            type="button"
            onClick={() => {
              setIsLogin(!isLogin);
              setStep(1);
              setError('');
            }}
            className="w-full mt-4 text-sm text-gray-600 hover:text-gray-900"
          >
            {isLogin
              ? 'Não tem uma conta? Criar conta'
              : 'Já tem uma conta? Fazer login'}
          </button>
        </div>
      </div>
    </div>
  );
}