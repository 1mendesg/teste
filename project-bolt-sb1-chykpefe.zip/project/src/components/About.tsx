import React from 'react';
import { History, Award, Users } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface SiteImage {
  id: string;
  title: string;
  section: string;
  current_image: string;
}

export function About() {
  const [factoryImage, setFactoryImage] = React.useState<string | null>(null);

  React.useEffect(() => {
    loadFactoryImage();
  }, []);

  const loadFactoryImage = async () => {
    try {
      const { data } = await supabase
        .from('site_images')
        .select('*')
        .eq('section', 'about')
        .eq('title', 'Imagem da Fábrica')
        .single();

      if (data?.current_image) {
        setFactoryImage(data.current_image);
      }
    } catch (error) {
      console.error('Error loading factory image:', error);
    }
  };

  return (
    <section id="about" className="py-16 bg-white">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Nossa História
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Desde 2000, a Usual Rótulos e Etiquetas tem sido referência em soluções personalizadas para identificação de produtos.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="text-center p-6">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <History className="w-8 h-8 text-[--primary]" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Nossa Trajetória</h3>
            <p className="text-lg text-gray-600">
              Começamos como uma pequena gráfica e hoje somos líderes no segmento de rótulos e etiquetas no sul do Brasil.
            </p>
          </div>

          <div className="text-center p-6">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Award className="w-8 h-8 text-[--primary]" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Compromisso com Qualidade</h3>
            <p className="text-lg text-gray-600">
              Investimos constantemente em tecnologia e processos para garantir a excelência em cada produto.
            </p>
          </div>

          <div className="text-center p-6">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-[--primary]" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Nossa Equipe</h3>
            <p className="text-lg text-gray-600">
              Contamos com profissionais especializados e apaixonados pelo que fazem.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <img
              src={factoryImage || "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80"}
              alt="Nossa Fábrica"
              className="rounded-lg shadow-lg"
            />
          </div>
          <div className="space-y-6">
            <h3 className="text-3xl font-bold mb-6">Sobre Nós.</h3>
            <p className="text-xl text-gray-700 leading-relaxed">
              A USUALITY é uma linha multiuso de produtos Autoadesivos, desenvolvida para oferecer soluções versáteis e de alta qualidade para diversas aplicações.
            </p>
            <p className="text-xl text-gray-700 leading-relaxed">
              Fazemos parte do Grupo Usual Rótulos, que há mais de 25 anos entrega soluções inovadoras em produtos Autoadesivos, garantindo excelência e tecnologia em cada item produzido.
            </p>
            <p className="text-xl text-gray-700 leading-relaxed">
              
Nossa sede está localizada em Palmeira, Paraná, onde asseguramos qualidade e inovação em cada etapa da produção. Além disso, contamos com nossa loja de fábrica em Curitiba, na Avenida Toaldo Túlio, 1735 – Santa Felicidade, para atender nossos clientes de perto com toda a expertise e variedade de produtos.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}