import { supabase } from '../../../lib/supabase';

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const { action, model, model_id, status } = req.body;

    // Log webhook data for debugging
    console.log('Melhor Envio webhook received:', {
      action,
      model,
      model_id,
      status
    });

    // Handle shipping label status updates
    if (model === 'shipment') {
      const { error } = await supabase
        .from('shipping_labels')
        .update({ 
          status: status,
          updated_at: new Date().toISOString()
        })
        .eq('melhor_envio_id', model_id);

      if (error) throw error;
    }

    return res.status(200).json({ message: 'Webhook processed successfully' });
  } catch (error) {
    console.error('Error processing Melhor Envio webhook:', error);
    return res.status(500).json({ message: 'Error processing webhook' });
  }
}