import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Solution {
  id: string;
  title: string;
  description: string;
  image_url: string;
}

interface Category {
  id: string;
  title: string;
  description: string;
  slug: string;
  image_url: string;
}

export function SolutionPage() {
  const { id } = useParams<{ id: string }>();
  const [solution, setSolution] = React.useState<Solution | null>(null);
  const [categories, setCategories] = React.useState<Category[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);

  React.useEffect(() => {
    loadData();
  }, [id]);

  const loadData = async () => {
    if (!id) return;

    try {
      const [solutionData, categoriesData] = await Promise.all([
        supabase
          .from('solutions')
          .select('*')
          .eq('id', id)
          .single(),
        supabase
          .from('categories')
          .select('*')
          .eq('solution_id', id)
          .order('sort_order', { ascending: true })
      ]);

      if (solutionData.data) setSolution(solutionData.data);
      if (categoriesData.data) setCategories(categoriesData.data);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen pt-32 pb-12 bg-white">
        <div className="container">
          <div className="text-center">Carregando...</div>
        </div>
      </div>
    );
  }

  if (!solution) {
    return (
      <div className="min-h-screen pt-32 pb-12 bg-white">
        <div className="container">
          <div className="text-center">Solução não encontrada</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-32 pb-12 bg-white">
      <div className="container">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">{solution.title}</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {solution.description}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((category) => (
            <Link key={category.id} to={`/produtos/${category.slug}`} className="group">
              <div className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-all">
                {/* Clique na imagem agora também redireciona */}
                <div className="relative h-48 cursor-pointer">
                  <img
                    src={category.image_url || 'https://images.unsplash.com/photo-1585386959984-a4155224a1ad?auto=format&fit=crop&q=80'}
                    alt={category.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{category.title}</h3>
                  <p className="text-gray-600 mb-4">{category.description}</p>
                  <span className="inline-flex items-center text-[--primary] font-semibold hover:text-[--primary-dark] transition-colors">
                    Ver Produtos
                    <ArrowRight className="ml-2" size={20} />
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
