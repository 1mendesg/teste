-- Add neighborhood column to user_profiles if it doesn't exist
ALTER TABLE user_profiles 
ADD COLUMN IF NOT EXISTS neighborhood text;

-- Update existing profiles to set a default value
UPDATE user_profiles 
SET neighborhood = ''
WHERE neighborhood IS NULL;