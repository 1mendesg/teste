import React from 'react';
import { Navigate, useNavigate, Link } from 'react-router-dom';
import { Package, Settings, Plus, Image, ArrowLeft, ShoppingBag, Trash2, Edit, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { getCurrentUser } from '../lib/auth';

interface Solution {
  id: string;
  title: string;
  description: string;
  image_url: string;
  sort_order: number;
}

interface Category {
  id: string;
  solution_id: string;
  title: string;
  description: string;
  slug: string;
  sort_order: number;
  image_url: string;
}

interface EditModal {
  type: 'solution' | 'category';
  item: Solution | Category | null;
}

export function AdminSolutionsPage() {
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = React.useState<boolean | null>(null);
  const [solutions, setSolutions] = React.useState<Solution[]>([]);
  const [categories, setCategories] = React.useState<Category[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [selectedImage, setSelectedImage] = React.useState<File | null>(null);
  const [imagePreview, setImagePreview] = React.useState<string>('');
  const [newSolution, setNewSolution] = React.useState({
    title: '',
    description: '',
  });
  const [newCategory, setNewCategory] = React.useState({
    solution_id: '',
    title: '',
    description: '',
  });
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [error, setError] = React.useState('');
  const [success, setSuccess] = React.useState('');
  const [editModal, setEditModal] = React.useState<EditModal | null>(null);

  React.useEffect(() => {
    checkAdminStatus();
    loadData();
  }, []);

  const checkAdminStatus = async () => {
    const user = await getCurrentUser();
    setIsAdmin(user?.email?.toLowerCase() === 'luciano@usualetiquetas.com.br');
  };

  const loadData = async () => {
    try {
      const [solutionsData, categoriesData] = await Promise.all([
        supabase
          .from('solutions')
          .select('*')
          .order('sort_order', { ascending: true }),
        supabase
          .from('categories')
          .select('*')
          .order('sort_order', { ascending: true }),
      ]);

      if (solutionsData.data) setSolutions(solutionsData.data);
      if (categoriesData.data) setCategories(categoriesData.data);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedImage(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleSolutionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setIsSubmitting(true);

    try {
      let image_url = '';

      if (selectedImage) {
        const fileExt = selectedImage.name.split('.').pop();
        const fileName = `${Math.random()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('site-images')
          .upload(fileName, selectedImage);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('site-images')
          .getPublicUrl(fileName);

        image_url = publicUrl;
      }

      const { error } = await supabase
        .from('solutions')
        .insert([{
          title: newSolution.title,
          description: newSolution.description,
          image_url,
          sort_order: solutions.length,
        }]);

      if (error) throw error;

      setSuccess('Solução criada com sucesso!');
      setNewSolution({ title: '', description: '' });
      setSelectedImage(null);
      setImagePreview('');
      await loadData();
    } catch (error) {
      console.error('Error creating solution:', error);
      setError('Erro ao criar solução. Por favor, tente novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCategorySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setIsSubmitting(true);

    try {
      let image_url = '';

      if (selectedImage) {
        const fileExt = selectedImage.name.split('.').pop();
        const fileName = `${Math.random()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('site-images')
          .upload(fileName, selectedImage);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('site-images')
          .getPublicUrl(fileName);

        image_url = publicUrl;
      }

      const slug = newCategory.title
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');

      const { error } = await supabase
        .from('categories')
        .insert([{
          solution_id: newCategory.solution_id,
          title: newCategory.title,
          description: newCategory.description,
          image_url,
          slug,
          sort_order: categories.filter(c => c.solution_id === newCategory.solution_id).length,
        }]);

      if (error) throw error;

      setSuccess('Categoria criada com sucesso!');
      setNewCategory({ solution_id: '', title: '', description: '' });
      setSelectedImage(null);
      setImagePreview('');
      await loadData();
    } catch (error) {
      console.error('Error creating category:', error);
      setError('Erro ao criar categoria. Por favor, tente novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (type: 'solution' | 'category', id: string) => {
    if (!window.confirm(`Tem certeza que deseja excluir esta ${type === 'solution' ? 'solução' : 'categoria'}?`)) {
      return;
    }

    try {
      const { error } = await supabase
        .from(type === 'solution' ? 'solutions' : 'categories')
        .delete()
        .eq('id', id);

      if (error) throw error;

      await loadData();
      setSuccess(`${type === 'solution' ? 'Solução' : 'Categoria'} excluída com sucesso!`);
    } catch (error) {
      console.error('Error deleting:', error);
      setError(`Erro ao excluir ${type === 'solution' ? 'solução' : 'categoria'}. Por favor, tente novamente.`);
    }
  };

  const handleEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editModal?.item) return;

    setError('');
    setSuccess('');
    setIsSubmitting(true);

    try {
      let image_url = editModal.item.image_url;

      if (selectedImage) {
        const fileExt = selectedImage.name.split('.').pop();
        const fileName = `${Math.random()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('site-images')
          .upload(fileName, selectedImage);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('site-images')
          .getPublicUrl(fileName);

        image_url = publicUrl;
      }

      const { error } = await supabase
        .from(editModal.type === 'solution' ? 'solutions' : 'categories')
        .update(
          editModal.type === 'solution' 
            ? {
                title: editModal.item.title,
                description: editModal.item.description,
                image_url
              }
            : {
                title: editModal.item.title,
                description: editModal.item.description,
                solution_id: (editModal.item as Category).solution_id,
                image_url,
                slug: editModal.item.title
                  .toLowerCase()
                  .normalize('NFD')
                  .replace(/[\u0300-\u036f]/g, '')
                  .replace(/[^a-z0-9]+/g, '-')
                  .replace(/(^-|-$)/g, '')
              }
        )
        .eq('id', editModal.item.id);

      if (error) throw error;

      setSuccess(`${editModal.type === 'solution' ? 'Solução' : 'Categoria'} atualizada com sucesso!`);
      setEditModal(null);
      setSelectedImage(null);
      setImagePreview('');
      await loadData();
    } catch (error) {
      console.error('Error updating:', error);
      setError(`Erro ao atualizar ${editModal.type === 'solution' ? 'solução' : 'categoria'}. Por favor, tente novamente.`);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isAdmin === null) {
    return <div>Carregando...</div>;
  }

  if (isAdmin === false) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-md">
        <div className="container mx-auto px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/')}
                className="flex items-center text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Voltar ao site
              </button>
              <span className="text-xl font-semibold text-gray-800">
                Painel Administrativo
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/admin')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <Settings size={20} />
                <span>Configurações</span>
              </button>
              <button
                onClick={() => navigate('/admin/produtos')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <Package size={20} />
                <span>Produtos</span>
              </button>
              <button
                onClick={() => navigate('/admin/pedidos')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <ShoppingBag size={20} />
                <span>Pedidos</span>
              </button>
              <button
                onClick={() => navigate('/admin/produtos/novo')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <Plus size={20} />
                <span>Novo Produto</span>
              </button>
              <button
                onClick={() => navigate('/admin/imagens')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <Image size={20} />
                <span>Imagens</span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-6 py-8">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Soluções */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-semibold mb-6">Soluções</h2>
            
            <form onSubmit={handleSolutionSubmit} className="space-y-4 mb-8">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Título
                </label>
                <input
                  type="text"
                  required
                  value={newSolution.title}
                  onChange={(e) => setNewSolution(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full p-2 border rounded-lg"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Descrição
                </label>
                <textarea
                  required
                  value={newSolution.description}
                  onChange={(e) => setNewSolution(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full p-2 border rounded-lg"
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Imagem
                </label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg">
                  <div className="space-y-1 text-center">
                    {imagePreview ? (
                      <div className="mb-4">
                        <img
                          src={imagePreview}
                          alt="Preview"
                          className="mx-auto h-32 w-32 object-cover rounded"
                        />
                      </div>
                    ) : (
                      <Image
                        className="mx-auto h-12 w-12 text-gray-400"
                        strokeWidth={1}
                      />
                    )}
                    <div className="flex text-sm text-gray-600">
                      <label className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                        <span>Upload a file</span>
                        <input
                          type="file"
                          className="sr-only"
                          accept="image/*"
                          onChange={handleImageChange}
                        />
                      </label>
                      <p className="pl-1">or drag and drop</p>
                    </div>
                    <p className="text-xs text-gray-500">
                      PNG, JPG, GIF up to 10MB
                    </p>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full btn bg-green-500 hover:bg-green-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? 'Salvando...' : 'Adicionar Solução'}
              </button>
            </form>

            <div className="space-y-4">
              {solutions.map((solution) => (
                <div
                  key={solution.id}
                  className="border rounded-lg p-4 flex justify-between items-start"
                >
                  <Link
                    to={`/solucoes/${solution.id}`}
                    className="flex-1"
                  >
                    <div className="flex items-center space-x-4">
                      <input
                        type="number"
                        min="0"
                        value={solution.sort_order || 0}
                        onChange={async (e) => {
                          const newOrder = parseInt(e.target.value);
                          try {
                            const { error } = await supabase
                              .from('solutions')
                              .update({ sort_order: newOrder })
                              .eq('id', solution.id);
                            
                            if (error) throw error;
                            await loadData();
                          } catch (err) {
                            console.error('Error updating order:', err);
                            setError('Erro ao atualizar ordem da solução');
                          }
                        }}
                        className="w-16 p-1 border rounded"
                        onClick={(e) => e.stopPropagation()}
                      />
                      <div>
                        <h3 className="font-semibold">{solution.title}</h3>
                        <p className="text-sm text-gray-600">{solution.description}</p>
                      </div>
                    </div>
                    {solution.image_url && (
                      <img
                        src={solution.image_url}
                        alt={solution.title}
                        className="mt-2 h-20 w-20 object-cover rounded"
                      />
                    )}
                  </Link>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => setEditModal({ type: 'solution', item: solution })}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      <Edit size={20} />
                    </button>
                    <button
                      onClick={() => handleDelete('solution', solution.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Categorias */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-semibold mb-6">Categorias</h2>
            
            <form onSubmit={handleCategorySubmit} className="space-y-4 mb-8">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Solução
                </label>
                <select
                  required
                  value={newCategory.solution_id}
                  onChange={(e) => setNewCategory(prev => ({ ...prev, solution_id: e.target.value }))}
                  className="w-full p-2 border rounded-lg"
                >
                  <option value="">Selecione uma solução</option>
                  {solutions.map((solution) => (
                    <option key={solution.id} value={solution.id}>
                      {solution.title}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Título
                </label>
                <input
                  type="text"
                  required
                  value={newCategory.title}
                  onChange={(e) => setNewCategory(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full p-2 border rounded-lg"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Descrição
                </label>
                <textarea
                  required
                  value={newCategory.description}
                  onChange={(e) => setNewCategory(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full p-2 border rounded-lg"
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Imagem
                </label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg">
                  <div className="space-y-1 text-center">
                    {imagePreview ? (
                      <div className="mb-4">
                        <img
                          src={imagePreview}
                          alt="Preview"
                          className="mx-auto h-32 w-32 object-cover rounded"
                        />
                      </div>
                    ) : (
                      <Image
                        className="mx-auto h-12 w-12 text-gray-400"
                        strokeWidth={1}
                      />
                    )}
                    <div className="flex text-sm text-gray-600">
                      <label className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                        <span>Upload a file</span>
                        <input
                          type="file"
                          className="sr-only"
                          accept="image/*"
                          onChange={handleImageChange}
                        />
                      </label>
                      <p className="pl-1">or drag and drop</p>
                    </div>
                    <p className="text-xs text-gray-500">
                      PNG, JPG, GIF up to 10MB
                    </p>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full btn bg-green-500 hover:bg-green-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? 'Salvando...' : 'Adicionar Categoria'}
              </button>
            </form>

            <div className="space-y-4">
              {categories.map((category) => (
                <div
                  key={category.id}
                  className="border rounded-lg p-4 flex justify-between items-start"
                >
                  <Link
                    to={`/produtos/${category.slug}`}
                    className="flex-1"
                  >
                    <div className="flex items-center space-x-4">
                      <input
                        type="number"
                        min="0"
                        value={category.sort_order || 0}
                        onChange={async (e) => {
                          const newOrder = parseInt(e.target.value);
                          try {
                            const { error } = await supabase
                              .from('categories')
                              .update({ sort_order: newOrder })
                              .eq('id', category.id);
                            
                            if (error) throw error;
                            await loadData();
                          } catch (err) {
                            console.error('Error updating order:', err);
                            setError('Erro ao atualizar ordem da categoria');
                          }
                        }}
                        className="w-16 p-1 border rounded"
                        onClick={(e) => e.stopPropagation()}
                      />
                      <div>
                        <h3 className="font-semibold">{category.title}</h3>
                        <p className="text-sm text-gray-600">{category.description}</p>
                        <p className="text-xs text-gray-500">
                          Solução: {solutions.find(s => s.id === category.solution_id)?.title}
                        </p>
                      </div>
                    </div>
                    {category.image_url && (
                      <img
                        src={category.image_url}
                        alt={category.title}
                        className="mt-2 h-20 w-20 object-cover rounded"
                      />
                    )}
                  </Link>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => setEditModal({ type: 'category', item: category })}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      <Edit size={20} />
                    </button>
                    <button
                      onClick={() => handleDelete('category', category.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {error && (
          <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-lg">
            {error}
          </div>
        )}

        {success && (
          <div className="mt-4 p-4 bg-green-50 text-green-700 rounded-lg">
            {success}
          </div>
        )}

        {/* Edit Modal */}
        {editModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg max-w-md w-full">
              <div className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold">
                    Editar {editModal.type === 'solution' ? 'Solução' : 'Categoria'}
                  </h2>
                  <button
                    onClick={() => {
                      setEditModal(null);
                      setSelectedImage(null);
                      setImagePreview('');
                    }}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <X size={24} />
                  </button>
                </div>

                <form onSubmit={handleEdit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Título
                    </label>
                    <input
                      type="text"
                      required
                      value={editModal.item.title}
                      onChange={(e) => setEditModal(prev => prev ? {
                        ...prev,
                        item: { ...prev.item, title: e.target.value }
                      } : null)}
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Descrição
                    </label>
                    <textarea
                      required
                      value={editModal.item.description}
                      onChange={(e) => setEditModal(prev => prev ? {
                        ...prev,
                        item: { ...prev.item, description: e.target.value }
                      } : null)}
                      className="w-full p-2 border rounded-lg"
                      rows={3}
                    />
                  </div>

                  {editModal.type === 'category' && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Solução
                      </label>
                      <select
                        required
                        value={(editModal.item as Category).solution_id}
                        onChange={(e) => setEditModal(prev => prev ? {
                          ...prev,
                          item: { ...prev.item, solution_id: e.target.value }
                        } : null)}
                        className="w-full p-2 border rounded-lg"
                      >
                        {solutions.map((solution) => (
                          <option key={solution.id} value={solution.id}>
                            {solution.title}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Imagem
                    </label>
                    <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg">
                      <div className="space-y-1 text-center">
                        {imagePreview || editModal.item.image_url ? (
                          <div className="mb-4">
                            <img
                              src={imagePreview || editModal.item.image_url}
                              alt="Preview"
                              className="mx-auto h-32 w-32 object-cover rounded"
                            />
                          </div>
                        ) : (
                          <Image
                            className="mx-auto h-12 w-12 text-gray-400"
                            strokeWidth={1}
                          />
                        )}
                        <div className="flex text-sm text-gray-600">
                          <label className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                            <span>Upload a file</span>
                            <input
                              type="file"
                              className="sr-only"
                              accept="image/*"
                              onChange={handleImageChange}
                            />
                          </label>
                          <p className="pl-1">or drag and drop</p>
                        </div>
                        <p className="text-xs text-gray-500">
                          PNG, JPG, GIF up to 10MB
                        </p>
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full btn bg-green-500 hover:bg-green-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? 'Salvando...' : 'Salvar Alterações'}
                  </button>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}