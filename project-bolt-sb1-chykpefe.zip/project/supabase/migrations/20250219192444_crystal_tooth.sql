-- Create shipping_cep_ranges table
CREATE TABLE IF NOT EXISTS shipping_cep_ranges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  start_cep text NOT NULL,
  end_cep text NOT NULL,
  base_price numeric NOT NULL DEFAULT 0,
  weight_multiplier numeric NOT NULL DEFAULT 1,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE shipping_cep_ranges ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can read shipping ranges"
  ON shipping_cep_ranges
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Only admin can modify shipping ranges"
  ON shipping_cep_ranges
  FOR ALL
  TO authenticated
  USING (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br')
  WITH CHECK (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br');

-- Create indexes for better performance
CREATE INDEX shipping_cep_ranges_start_cep_idx ON shipping_cep_ranges(start_cep);
CREATE INDEX shipping_cep_ranges_end_cep_idx ON shipping_cep_ranges(end_cep);

-- Create updated_at trigger
CREATE TRIGGER update_shipping_cep_ranges_updated_at
  BEFORE UPDATE ON shipping_cep_ranges
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Add constraints to ensure valid CEP ranges
ALTER TABLE shipping_cep_ranges
ADD CONSTRAINT valid_cep_length CHECK (
  length(start_cep) = 8 AND 
  length(end_cep) = 8
),
ADD CONSTRAINT valid_cep_range CHECK (
  start_cep <= end_cep
),
ADD CONSTRAINT positive_base_price CHECK (
  base_price >= 0
),
ADD CONSTRAINT positive_weight_multiplier CHECK (
  weight_multiplier >= 1
);