import React from 'react';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import { CheckCircle, ArrowLeft } from 'lucide-react';
import { useCart } from '../lib/cart';
import { supabase } from '../lib/supabase';

export function CheckoutSuccessPage() {
  const clearCart = useCart((state) => state.clearCart);
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = React.useState(true);
  const [error, setError] = React.useState('');

  React.useEffect(() => {
    const updateOrderStatus = async () => {
      try {
        const paymentId = searchParams.get('payment_id');
        const status = searchParams.get('status');
        const externalReference = searchParams.get('external_reference');

        if (!paymentId || !status || !externalReference) {
          throw new Error('Missing payment information');
        }

        const { error: updateError } = await supabase
          .from('orders')
          .update({
            payment_status: status,
            payment_id: paymentId,
            status: status === 'approved' ? 'processing' : 'pending'
          })
          .eq('id', externalReference);

        if (updateError) throw updateError;

        clearCart();
        setIsProcessing(false);
      } catch (err) {
        console.error('Error updating order status:', err);
        setError('Erro ao processar o pagamento. Por favor, entre em contato com o suporte.');
        setIsProcessing(false);
      }
    };

    updateOrderStatus();
  }, [searchParams, clearCart, navigate]);

  if (isProcessing) {
    return (
      <div className="min-h-screen pt-32 pb-12 bg-gray-50">
        <div className="container max-w-2xl mx-auto px-4">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 mx-auto mb-4"></div>
            <p className="text-lg text-gray-600">Processando seu pagamento...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen pt-32 pb-12 bg-gray-50">
        <div className="container max-w-2xl mx-auto px-4">
          <div className="text-center">
            <div className="text-red-500 mb-4">
              <svg className="w-16 h-16 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h1 className="text-3xl font-bold mb-4">Ops! Algo deu errado</h1>
            <p className="text-gray-600 mb-8">{error}</p>
            <Link
              to="/"
              className="inline-flex items-center text-blue-600 hover:text-blue-800"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar à Página Inicial
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-32 pb-12 bg-gray-50">
      <div className="container max-w-2xl mx-auto px-4">
        <div className="text-center">
          <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-6" />
          <h1 className="text-3xl font-bold mb-4">Pedido Realizado com Sucesso!</h1>
          <p className="text-gray-600 mb-8">
            Obrigado por sua compra! Você receberá um e-mail com os detalhes do pedido.
          </p>
          <Link
            to="/"
            className="inline-flex items-center text-blue-600 hover:text-blue-800"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar à Página Inicial
          </Link>
        </div>
      </div>
    </div>
  );
}