import React from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { Package, Settings, Plus, Image, ArrowLeft, ShoppingBag, Clock } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { getCurrentUser } from '../lib/auth';

interface Order {
  id: string;
  user_id: string;
  items: Array<{
    id: string;
    name: string;
    price: number;
    quantity: number;
    size: string;
    image_url: string;
  }>;
  total_price: number;
  status: string;
  payment_status: string;
  shipping_address: {
    street: string;
    number: string;
    complement?: string;
    neighborhood: string;
    city: string;
    state: string;
    zip_code: string;
  };
  selected_shipping: {
    name: string;
    price: number;
    company: {
      name: string;
    };
  };
  created_at: string;
  user: {
    email: string;
  };
  user_profile: {
    full_name: string;
    company_name: string;
    phone: string;
  }[];
}

export function AdminOrdersPage() {
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = React.useState<boolean | null>(null);
  const [orders, setOrders] = React.useState<Order[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [isProcessing, setIsProcessing] = React.useState<string | null>(null);

  React.useEffect(() => {
    checkAdminStatus();
    loadOrders();
  }, []);

  const checkAdminStatus = async () => {
    const user = await getCurrentUser();
    setIsAdmin(user?.email?.toLowerCase() === 'luciano@usualetiquetas.com.br');
  };

  const loadOrders = async () => {
    try {
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          user:user_id(email),
          user_profile:user_profiles(
            full_name,
            company_name,
            phone
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setOrders(data || []);
    } catch (error) {
      console.error('Error loading orders:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      setIsProcessing(orderId);
      const { error } = await supabase
        .from('orders')
        .update({ status: newStatus })
        .eq('id', orderId);

      if (error) throw error;
      await loadOrders();
    } catch (error) {
      console.error('Error updating order status:', error);
    } finally {
      setIsProcessing(null);
    }
  };

  if (isAdmin === null) {
    return <div>Carregando...</div>;
  }

  if (isAdmin === false) {
    return <Navigate to="/" replace />;
  }

  const OrderCard = ({ order }: { order: Order }) => (
    <div className="bg-white rounded-lg shadow-md p-6 mb-4">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-semibold">
            Pedido #{order.id.slice(0, 8)}
          </h3>
          <p className="text-sm text-gray-500">
            {new Date(order.created_at).toLocaleString()}
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
            order.payment_status === 'approved' 
              ? 'bg-green-100 text-green-800' 
              : 'bg-yellow-100 text-yellow-800'
          }`}>
            {order.payment_status === 'approved' ? 'Pago' : 'Pendente'}
          </span>
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
            order.status === 'completed' 
              ? 'bg-green-100 text-green-800'
              : order.status === 'processing'
              ? 'bg-blue-100 text-blue-800'
              : 'bg-gray-100 text-gray-800'
          }`}>
            {order.status === 'completed' 
              ? 'Finalizado'
              : order.status === 'processing'
              ? 'Em Processamento'
              : 'Pendente'}
          </span>
        </div>
      </div>

      <div className="mb-6">
        <h4 className="font-medium mb-2">Dados do Cliente</h4>
        <div className="text-sm text-gray-600 space-y-1">
          <p>Email: {order.user.email}</p>
          <p>Nome: {order.user_profile?.[0]?.full_name || 'N/A'}</p>
          <p>Empresa: {order.user_profile?.[0]?.company_name || 'N/A'}</p>
          <p>Telefone: {order.user_profile?.[0]?.phone || 'N/A'}</p>
        </div>
      </div>

      <div className="mb-6">
        <h4 className="font-medium mb-2">Produtos</h4>
        <div className="space-y-4">
          {order.items.map((item, index) => (
            <div key={index} className="flex items-center space-x-4">
              <img 
                src={item.image_url} 
                alt={item.name}
                className="w-16 h-16 object-cover rounded"
              />
              <div className="flex-1">
                <p className="font-medium">{item.name}</p>
                <p className="text-sm text-gray-600">Tamanho: {item.size}</p>
                <p className="text-sm text-gray-600">Quantidade: {item.quantity}</p>
                <p className="text-sm font-medium">R$ {item.price.toFixed(2)}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {order.shipping_address && (
        <div className="mb-6">
          <h4 className="font-medium mb-2">Endereço de Entrega</h4>
          <div className="text-sm text-gray-600">
            <p>
              {order.shipping_address.street}, {order.shipping_address.number}
              {order.shipping_address.complement && `, ${order.shipping_address.complement}`}
            </p>
            <p>{order.shipping_address.neighborhood}</p>
            <p>
              {order.shipping_address.city} - {order.shipping_address.state}
            </p>
            <p>CEP: {order.shipping_address.zip_code}</p>
          </div>
        </div>
      )}

      {order.selected_shipping && (
        <div className="border-t pt-4">
          <div className="flex justify-between items-center">
            <div className="text-sm text-gray-600">
              <p>Frete: {order.selected_shipping.name}</p>
              <p>Transportadora: {order.selected_shipping.company.name}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">
                Frete: R$ {order.selected_shipping.price.toFixed(2)}
              </p>
              <p className="text-lg font-bold text-green-600">
                Total: R$ {order.total_price.toFixed(2)}
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="flex justify-end mt-4 pt-4 border-t">
        <select
          value={order.status}
          onChange={(e) => updateOrderStatus(order.id, e.target.value)}
          className="text-sm border rounded p-2"
          disabled={isProcessing === order.id}
        >
          <option value="pending">Pendente</option>
          <option value="processing">Em Processamento</option>
          <option value="completed">Finalizado</option>
        </select>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-md">
        <div className="container mx-auto px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/')}
                className="flex items-center text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Voltar ao site
              </button>
              <span className="text-xl font-semibold text-gray-800">
                Painel Administrativo
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/admin')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <Settings size={20} />
                <span>Configurações</span>
              </button>
              <button
                onClick={() => navigate('/admin/produtos')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <Package size={20} />
                <span>Produtos</span>
              </button>
              <button
                onClick={() => navigate('/admin/pedidos')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-blue-50 text-blue-600"
              >
                <ShoppingBag size={20} />
                <span>Pedidos</span>
              </button>
              <button
                onClick={() => navigate('/admin/produtos/novo')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <Plus size={20} />
                <span>Novo Produto</span>
              </button>
              <button
                onClick={() => navigate('/admin/imagens')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <Image size={20} />
                <span>Imagens</span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-6 py-8">
        <div className="flex items-center space-x-2 mb-8">
          <ShoppingBag className="w-6 h-6 text-gray-600" />
          <h1 className="text-3xl font-bold">Todos os Pedidos</h1>
          <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded-full">
            {orders.length}
          </span>
        </div>

        {orders.length === 0 ? (
          <div className="bg-white rounded-lg shadow-lg p-6 text-center">
            <Clock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Nenhum pedido encontrado</p>
          </div>
        ) : (
          <div className="space-y-6">
            {orders.map(order => (
              <OrderCard key={order.id} order={order} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}