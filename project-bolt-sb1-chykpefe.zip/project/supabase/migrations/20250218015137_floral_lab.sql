-- Add about section to site_images check constraint
ALTER TABLE site_images 
DROP CONSTRAINT site_images_section_check,
ADD CONSTRAINT site_images_section_check 
CHECK (section IN ('banner', 'solution', 'custom_label', 'logo', 'about'));

-- Add about image
INSERT INTO site_images (title, description, section)
VALUES ('Imagem da Fábrica', 'Imagem da fábrica exibida na seção Sobre', 'about')
ON CONFLICT DO NOTHING;