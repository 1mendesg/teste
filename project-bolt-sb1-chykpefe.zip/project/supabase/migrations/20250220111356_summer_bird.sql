-- Add express_surcharge column if it doesn't exist
ALTER TABLE shipping_config 
ADD COLUMN IF NOT EXISTS express_surcharge numeric NOT NULL DEFAULT 12;

-- Update existing config with express_surcharge if needed
UPDATE shipping_config
SET express_surcharge = 12
WHERE express_surcharge IS NULL;

-- Drop existing policies if they exist
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Anyone can read shipping config" ON shipping_config;
    DROP POLICY IF EXISTS "Only admin can modify shipping config" ON shipping_config;
    
    -- Recreate policies
    CREATE POLICY "Anyone can read shipping config"
      ON shipping_config
      FOR SELECT
      TO public
      USING (true);

    CREATE POLICY "Only admin can modify shipping config"
      ON shipping_config
      FOR ALL
      TO authenticated
      USING (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br')
      WITH CHECK (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br');
END $$;