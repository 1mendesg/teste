/*
  # Add sort order to products

  1. Changes
    - Add sort_order column to products table
    - Create index for better performance
*/

-- Add sort_order to products if it doesn't exist
ALTER TABLE products 
ADD COLUMN IF NOT EXISTS sort_order integer NOT NULL DEFAULT 0;

-- Create index for better sorting performance
CREATE INDEX IF NOT EXISTS products_sort_order_idx ON products(sort_order);