import React from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { Upload, ArrowLeft, Settings, Package, Plus, Image, ShoppingBag } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { getCurrentUser } from '../lib/auth';

interface Solution {
  id: string;
  title: string;
}

interface Category {
  id: string;
  solution_id: string;
  title: string;
}

interface Dimension {
  size: string;
  price: number;
  discount_percentage: number;
  stock: number;
}

export function AdminNewProductPage() {
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = React.useState<boolean | null>(null);
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [dimensions, setDimensions] = React.useState<Dimension[]>([{ 
    size: '', 
    price: 0,
    discount_percentage: 0,
    stock: 0 
  }]);
  const [selectedImage, setSelectedImage] = React.useState<File | null>(null);
  const [imagePreview, setImagePreview] = React.useState<string>('');
  const [solutions, setSolutions] = React.useState<Solution[]>([]);
  const [categories, setCategories] = React.useState<Category[]>([]);
  const [formData, setFormData] = React.useState({
    name: '',
    description: '',
    solution_id: '',
    category_id: '',
    minQuantity: 1000,
    weightKg: 0,
    heightCm: 0,
    widthCm: 0,
    lengthCm: 0,
  });

  React.useEffect(() => {
    checkAdminStatus();
    loadSolutionsAndCategories();
  }, []);

  const checkAdminStatus = async () => {
    const user = await getCurrentUser();
    setIsAdmin(user?.email?.toLowerCase() === 'luciano@usualetiquetas.com.br');
  };

  const loadSolutionsAndCategories = async () => {
    try {
      const [solutionsData, categoriesData] = await Promise.all([
        supabase
          .from('solutions')
          .select('id, title')
          .order('sort_order', { ascending: true }),
        supabase
          .from('categories')
          .select('id, solution_id, title')
          .order('sort_order', { ascending: true })
      ]);

      if (solutionsData.data) setSolutions(solutionsData.data);
      if (categoriesData.data) setCategories(categoriesData.data);
    } catch (error) {
      console.error('Error loading solutions and categories:', error);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedImage(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleAddDimension = () => {
    setDimensions([...dimensions, { 
      size: '', 
      price: 0,
      discount_percentage: 0,
      stock: 0 
    }]);
  };

  const handleRemoveDimension = (index: number) => {
    setDimensions(dimensions.filter((_, i) => i !== index));
  };

  const handleDimensionChange = (index: number, field: keyof Dimension, value: string | number) => {
    const newDimensions = [...dimensions];
    if (field === 'price' || field === 'discount_percentage') {
      const numValue = value === '' ? 0 : parseFloat(value as string) || 0;
      newDimensions[index] = {
        ...newDimensions[index],
        [field]: numValue,
      };
    } else if (field === 'stock') {
      const numValue = parseInt(value as string, 10) || 0;
      newDimensions[index] = {
        ...newDimensions[index],
        stock: numValue,
      };
    } else {
      newDimensions[index] = {
        ...newDimensions[index],
        [field]: value,
      };
    }
    setDimensions(newDimensions);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      let image_url = '';

      if (selectedImage) {
        const fileExt = selectedImage.name.split('.').pop();
        const fileName = `${Math.random()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('product-images')
          .upload(fileName, selectedImage);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('product-images')
          .getPublicUrl(fileName);

        image_url = publicUrl;
      }

      const { error } = await supabase.from('products').insert([
        {
          name: formData.name,
          description: formData.description,
          solution_id: formData.solution_id,
          category_id: formData.category_id,
          dimensions: dimensions.map(dim => ({
            ...dim,
            discount_price: dim.price * (1 - dim.discount_percentage / 100)
          })),
          min_quantity: formData.minQuantity,
          image_url: image_url,
          weight_kg: formData.weightKg,
          height_cm: formData.heightCm,
          width_cm: formData.widthCm,
          length_cm: formData.lengthCm,
        },
      ]);

      if (error) throw error;

      navigate('/admin/produtos');
    } catch (error) {
      console.error('Error creating product:', error);
      alert('Erro ao criar produto. Por favor, tente novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isAdmin === null) {
    return <div>Carregando...</div>;
  }

  if (isAdmin === false) {
    return <Navigate to="/" replace />;
  }

  const filteredCategories = categories.filter(
    category => category.solution_id === formData.solution_id
  );

  return (
    <div className="min-h-screen bg-gray-100 pt-8">
      <div className="container mx-auto px-6">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center space-x-4 mb-8">
            <button
              onClick={() => navigate('/admin/produtos')}
              className="flex items-center text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Voltar
            </button>
            <h1 className="text-2xl font-semibold">Novo Produto</h1>
          </div>

          <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6">
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Solução
                </label>
                <select
                  required
                  value={formData.solution_id}
                  onChange={(e) =>
                    setFormData((prev) => ({ 
                      ...prev, 
                      solution_id: e.target.value,
                      category_id: '' // Reset category when solution changes
                    }))
                  }
                  className="w-full p-2 border rounded-lg"
                >
                  <option value="">Selecione uma solução</option>
                  {solutions.map((solution) => (
                    <option key={solution.id} value={solution.id}>
                      {solution.title}
                    </option>
                  ))}
                </select>
              </div>

              {formData.solution_id && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Categoria
                  </label>
                  <select
                    required
                    value={formData.category_id}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, category_id: e.target.value }))
                    }
                    className="w-full p-2 border rounded-lg"
                  >
                    <option value="">Selecione uma categoria</option>
                    {filteredCategories.map((category) => (
                      <option key={category.id} value={category.id}>
                        {category.title}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Título do Produto
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, name: e.target.value }))
                  }
                  className="w-full p-2 border rounded-lg"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Imagem do Produto
                </label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg">
                  <div className="space-y-1 text-center">
                    {imagePreview ? (
                      <div className="mb-4">
                        <img
                          src={imagePreview}
                          alt="Preview"
                          className="mx-auto h-32 w-32 object-cover rounded"
                        />
                      </div>
                    ) : (
                      <Image
                        className="mx-auto h-12 w-12 text-gray-400"
                        strokeWidth={1}
                      />
                    )}
                    <div className="flex text-sm text-gray-600">
                      <label className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                        <span>Upload a file</span>
                        <input
                          type="file"
                          className="sr-only"
                          accept="image/*"
                          onChange={handleImageChange}
                        />
                      </label>
                      <p className="pl-1">or drag and drop</p>
                    </div>
                    <p className="text-xs text-gray-500">
                      PNG, JPG, GIF up to 10MB
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Descrição
                </label>
                <textarea
                  required
                  value={formData.description}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, description: e.target.value }))
                  }
                  rows={4}
                  className="w-full p-2 border rounded-lg"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Quantidade Mínima
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  value={formData.minQuantity}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, minQuantity: parseInt(e.target.value, 10) || 1000 }))
                  }
                  className="w-full p-2 border rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Peso (kg)
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    step="0.001"
                    value={formData.weightKg}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, weightKg: parseFloat(e.target.value) || 0 }))
                    }
                    className="w-full p-2 border rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Altura (cm)
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={formData.heightCm}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, heightCm: parseInt(e.target.value, 10) || 0 }))
                    }
                    className="w-full p-2 border rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Largura (cm)
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={formData.widthCm}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, widthCm: parseInt(e.target.value, 10) || 0 }))
                    }
                    className="w-full p-2 border rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Comprimento (cm)
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={formData.lengthCm}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, lengthCm: parseInt(e.target.value, 10) || 0 }))
                    }
                    className="w-full p-2 border rounded-lg"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Medidas, Preços e Estoque
                  </label>
                  <button
                    type="button"
                    onClick={handleAddDimension}
                    className="text-sm text-blue-600 hover:text-blue-800"
                  >
                    + Adicionar Medida
                  </button>
                </div>
                {dimensions.map((dimension, index) => (
                  <div key={index} className="grid grid-cols-5 gap-4 mb-4">
                    <div>
                      <input
                        type="text"
                        placeholder="Medida"
                        required
                        value={dimension.size}
                        onChange={(e) => handleDimensionChange(index, 'size', e.target.value)}
                        className="w-full p-2 border rounded-lg"
                      />
                    </div>
                    <div>
                      <input
                        type="number"
                        placeholder="Preço"
                        required
                        min="0"
                        step="0.01"
                        value={dimension.price}
                        onChange={(e) => handleDimensionChange(index, 'price', e.target.value)}
                        className="w-full p-2 border rounded-lg"
                      />
                    </div>
                    <div>
                      <input
                        type="number"
                        placeholder="Desconto (%)"
                        min="0"
                        max="100"
                        step="0.1"
                        value={dimension.discount_percentage}
                        onChange={(e) => handleDimensionChange(index, 'discount_percentage', e.target.value)}
                        className="w-full p-2 border rounded-lg"
                      />
                    </div>
                    <div>
                      <input
                        type="number"
                        placeholder="Estoque"
                        required
                        min="0"
                        value={dimension.stock}
                        onChange={(e) => handleDimensionChange(index, 'stock', e.target.value)}
                        className="w-full p-2 border rounded-lg"
                      />
                    </div>
                    <div className="flex items-center">
                      {dimensions.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveDimension(index)}
                          className="text-red-600 hover:text-red-800 px-2"
                        >
                          ×
                        </button>
                      )}
                      {dimension.discount_percentage > 0 && (
                        <div className="text-sm text-gray-500">
                          Preço final: R$ {(dimension.price * (1 - dimension.discount_percentage / 100)).toFixed(2)}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full btn bg-green-500 hover:bg-green-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? 'Salvando...' : 'Salvar Produto'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}