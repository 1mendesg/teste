-- Create shipping_config table
CREATE TABLE IF NOT EXISTS shipping_config (
  id text PRIMARY KEY DEFAULT '1',
  origin_cep text NOT NULL DEFAULT '84130000',
  min_weight_kg numeric NOT NULL DEFAULT 0.3,
  max_weight_kg numeric NOT NULL DEFAULT 30,
  min_dimension_cm integer NOT NULL DEFAULT 16,
  max_dimension_cm integer NOT NULL DEFAULT 105,
  weight_multiplier numeric NOT NULL DEFAULT 1,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT single_config CHECK (id = '1')
);

-- Enable RLS
ALTER TABLE shipping_config ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can read shipping config"
  ON shipping_config
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Only admin can modify shipping config"
  ON shipping_config
  FOR ALL
  TO authenticated
  USING (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br')
  WITH CHECK (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br');

-- Insert default config
INSERT INTO shipping_config (
  id,
  origin_cep,
  min_weight_kg,
  max_weight_kg,
  min_dimension_cm,
  max_dimension_cm,
  weight_multiplier
) VALUES (
  '1',
  '84130000',
  0.3,
  30,
  16,
  105,
  1
) ON CONFLICT (id) DO NOTHING;

-- Create updated_at trigger
CREATE TRIGGER update_shipping_config_updated_at
  BEFORE UPDATE ON shipping_config
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();