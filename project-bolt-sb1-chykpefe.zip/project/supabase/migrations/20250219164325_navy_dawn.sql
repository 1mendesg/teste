-- Add shipping fields to products table
ALTER TABLE products
ADD COLUMN IF NOT EXISTS weight_kg numeric(10,3) NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS height_cm integer NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS width_cm integer NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS length_cm integer NOT NULL DEFAULT 0;

-- Create shipping_labels table
CREATE TABLE IF NOT EXISTS shipping_labels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  melhor_envio_id text,
  carrier text NOT NULL,
  tracking_code text,
  label_url text,
  status text NOT NULL DEFAULT 'pending',
  shipping_cost numeric(10,2) NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE shipping_labels ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Admin can manage shipping labels"
  ON shipping_labels
  FOR ALL
  TO authenticated
  USING (auth.email() = 'luciano@usualetiquetas.com.br')
  WITH CHECK (auth.email() = 'luciano@usualetiquetas.com.br');

CREATE POLICY "Users can view their own shipping labels"
  ON shipping_labels
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = shipping_labels.order_id
      AND orders.user_id = auth.uid()
    )
  );

-- Add shipping fields to orders table
ALTER TABLE orders
ADD COLUMN IF NOT EXISTS shipping_address jsonb,
ADD COLUMN IF NOT EXISTS selected_shipping jsonb;