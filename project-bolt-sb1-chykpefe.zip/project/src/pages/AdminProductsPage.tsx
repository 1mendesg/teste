import React from 'react';
import { Navigate, Link, useNavigate } from 'react-router-dom';
import { Plus, Edit, Trash2, ArrowLeft, Settings, Package, Image, ShoppingBag, X, AlertTriangle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { getCurrentUser } from '../lib/auth';

interface Dimension {
  size: string;
  price: number;
  discount_percentage: number;
  stock: number;
}

interface Product {
  id: string;
  name: string;
  description: string;
  category_id: string;
  solution_id: string;
  dimensions: Array<{
    size: string;
    price: number;
    discount_price: number | null;
    stock: number;
  }>;
  min_quantity: number;
  image_url: string;
  sort_order?: number;
  weight_kg: number;
  height_cm: number;
  width_cm: number;
  length_cm: number;
}

interface Solution {
  id: string;
  title: string;
}

interface Category {
  id: string;
  solution_id: string;
  title: string;
}

const LOW_STOCK_THRESHOLD = 50;

export function AdminProductsPage() {
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = React.useState<boolean | null>(null);
  const [products, setProducts] = React.useState<Product[]>([]);
  const [isDeleting, setIsDeleting] = React.useState<string | null>(null);
  const [editingProduct, setEditingProduct] = React.useState<Product | null>(null);
  const [selectedImage, setSelectedImage] = React.useState<File | null>(null);
  const [imagePreview, setImagePreview] = React.useState<string>('');
  const [solutions, setSolutions] = React.useState<Solution[]>([]);
  const [categories, setCategories] = React.useState<Category[]>([]);
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [error, setError] = React.useState('');
  const [success, setSuccess] = React.useState('');

  React.useEffect(() => {
    checkAdminStatus();
    loadProducts();
    loadSolutionsAndCategories();
  }, []);

  const checkAdminStatus = async () => {
    const user = await getCurrentUser();
    setIsAdmin(user?.email?.toLowerCase() === 'luciano@usualetiquetas.com.br');
  };

  const loadProducts = async () => {
    const { data } = await supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (data) {
      setProducts(data);
    }
  };

  const loadSolutionsAndCategories = async () => {
    try {
      const [solutionsData, categoriesData] = await Promise.all([
        supabase
          .from('solutions')
          .select('id, title')
          .order('sort_order', { ascending: true }),
        supabase
          .from('categories')
          .select('id, solution_id, title')
          .order('sort_order', { ascending: true })
      ]);

      if (solutionsData.data) setSolutions(solutionsData.data);
      if (categoriesData.data) setCategories(categoriesData.data);
    } catch (error) {
      console.error('Error loading solutions and categories:', error);
    }
  };

  const handleDelete = async (productId: string) => {
    if (!window.confirm('Tem certeza que deseja excluir este produto?')) {
      return;
    }

    setIsDeleting(productId);
    try {
      if (products.find(p => p.id === productId)?.image_url) {
        const imagePath = products.find(p => p.id === productId)?.image_url.split('/').pop();
        if (imagePath) {
          await supabase.storage
            .from('product-images')
            .remove([imagePath]);
        }
      }

      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', productId);

      if (error) throw error;

      setProducts(products.filter(p => p.id !== productId));
      setSuccess('Produto excluído com sucesso!');
    } catch (error) {
      console.error('Error deleting product:', error);
      setError('Erro ao excluir o produto. Por favor, tente novamente.');
    } finally {
      setIsDeleting(null);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedImage(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;

    setIsSubmitting(true);
    setError('');
    setSuccess('');

    try {
      let image_url = editingProduct.image_url;

      if (selectedImage) {
        const fileExt = selectedImage.name.split('.').pop();
        const fileName = `${Math.random()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('product-images')
          .upload(fileName, selectedImage);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('product-images')
          .getPublicUrl(fileName);

        image_url = publicUrl;
      }

      const { error } = await supabase
        .from('products')
        .update({
          name: editingProduct.name,
          description: editingProduct.description,
          solution_id: editingProduct.solution_id,
          category_id: editingProduct.category_id,
          dimensions: editingProduct.dimensions.map(dim => ({
            ...dim,
            discount_price: dim.price * (1 - (dim.discount_percentage || 0) / 100)
          })),
          min_quantity: editingProduct.min_quantity,
          image_url,
          weight_kg: editingProduct.weight_kg,
          height_cm: editingProduct.height_cm,
          width_cm: editingProduct.width_cm,
          length_cm: editingProduct.length_cm,
        })
        .eq('id', editingProduct.id);

      if (error) throw error;

      setSuccess('Produto atualizado com sucesso!');
      setEditingProduct(null);
      setSelectedImage(null);
      setImagePreview('');
      await loadProducts();
    } catch (error) {
      console.error('Error updating product:', error);
      setError('Erro ao atualizar o produto. Por favor, tente novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDimensionChange = (index: number, field: keyof Dimension, value: string | number) => {
    if (!editingProduct) return;

    const newDimensions = [...editingProduct.dimensions];
    if (field === 'price' || field === 'discount_percentage') {
      const numValue = value === '' ? 0 : parseFloat(value as string) || 0;
      newDimensions[index] = {
        ...newDimensions[index],
        [field]: numValue,
      };
    } else if (field === 'stock') {
      const numValue = parseInt(value as string, 10) || 0;
      newDimensions[index] = {
        ...newDimensions[index],
        stock: numValue,
      };
    } else {
      newDimensions[index] = {
        ...newDimensions[index],
        [field]: value,
      };
    }
    setEditingProduct({ ...editingProduct, dimensions: newDimensions });
  };

  const handleAddDimension = () => {
    if (!editingProduct) return;
    setEditingProduct({
      ...editingProduct,
      dimensions: [
        ...editingProduct.dimensions,
        { size: '', price: 0, discount_percentage: 0, stock: 0 }
      ]
    });
  };

  const handleRemoveDimension = (index: number) => {
    if (!editingProduct) return;
    const newDimensions = editingProduct.dimensions.filter((_, i) => i !== index);
    setEditingProduct({ ...editingProduct, dimensions: newDimensions });
  };

  const hasLowStock = (product: Product) => {
    return product.dimensions.some(dim => dim.stock <= LOW_STOCK_THRESHOLD);
  };

  if (isAdmin === null) {
    return <div>Carregando...</div>;
  }

  if (isAdmin === false) {
    return <Navigate to="/" replace />;
  }

  const filteredCategories = categories.filter(
    category => category.solution_id === editingProduct?.solution_id
  );

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-md">
        <div className="container mx-auto px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/')}
                className="flex items-center text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Voltar ao site
              </button>
              <span className="text-xl font-semibold text-gray-800">
                Painel Administrativo
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/admin')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <Settings size={20} />
                <span>Configurações</span>
              </button>
              <button
                onClick={() => navigate('/admin/produtos')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-blue-50 text-blue-600"
              >
                <Package size={20} />
                <span>Produtos</span>
              </button>
              <button
                onClick={() => navigate('/admin/pedidos')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <ShoppingBag size={20} />
                <span>Pedidos</span>
              </button>
              <button
                onClick={() => navigate('/admin/produtos/novo')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <Plus size={20} />
                <span>Novo Produto</span>
              </button>
              <button
                onClick={() => navigate('/admin/imagens')}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                <Image size={20} />
                <span>Imagens</span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-6 py-8">
        {error && (
          <div className="mb-4 p-4 bg-red-50 text-red-700 rounded-lg">
            {error}
          </div>
        )}

        {success && (
          <div className="mb-4 p-4 bg-green-50 text-green-700 rounded-lg">
            {success}
          </div>
        )}

        <div className="bg-white rounded-lg shadow-md">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Ordem
                  </th>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Imagem
                  </th>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Nome
                  </th>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Medidas e Preços
                  </th>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Qtd. Mínima
                  </th>
                  <th className="px-6 py-3 bg-gray-50"></th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {products.map((product) => (
                  <tr key={product.id} className={hasLowStock(product) ? 'bg-yellow-50' : ''}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        <input
                          type="number"
                          min="0"
                          value={product.sort_order || 0}
                          onChange={async (e) => {
                            const newOrder = parseInt(e.target.value);
                            try {
                              const { error } = await supabase
                                .from('products')
                                .update({ sort_order: newOrder })
                                .eq('id', product.id);
                              
                              if (error) throw error;
                              await loadProducts();
                            } catch (err) {
                              console.error('Error updating order:', err);
                              setError('Erro ao atualizar ordem do produto');
                            }
                          }}
                          className="w-16 p-1 border rounded"
                        />
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <img
                        src={product.image_url}
                        alt={product.name}
                        className="h-12 w-12 object-cover rounded"
                      />
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-medium text-gray-900">{product.name}</div>
                      <div className="text-sm text-gray-500">{product.description}</div>
                      {hasLowStock(product) && (
                        <div className="flex items-center space-x-1 text-yellow-600 mt-1">
                          <AlertTriangle className="w-4 h-4" />
                          <span className="text-xs font-medium">Estoque baixo</span>
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="space-y-1">
                        {product.dimensions.map((dim, index) => (
                          <div key={index} className="text-sm">
                            <span className="font-medium">{dim.size}:</span>
                            {dim.discount_price ? (
                              <span>
                                <span className="line-through text-gray-500 ml-1">
                                  R$ {dim.price.toFixed(2)}
                                </span>
                                <span className="text-green-600 ml-1">
                                  R$ {dim.discount_price.toFixed(2)}
                                </span>
                              </span>
                            ) : (
                              <span className="ml-1">
                                R$ {dim.price.toFixed(2)}
                              </span>
                            )}
                            <span className={`ml-2 ${dim.stock <= LOW_STOCK_THRESHOLD ? 'text-yellow-600' : 'text-gray-500'}`}>
                              (Estoque: {dim.stock})
                            </span>
                          </div>
                        ))}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {product.min_quantity} un.
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <button
                        onClick={() => setEditingProduct(product)}
                        className="text-blue-600 hover:text-blue-800 mr-4"
                        title="Editar"
                      >
                        <Edit size={20} />
                      </button>
                      <button
                        className="text-red-600 hover:text-red-800 disabled:opacity-50"
                        title="Excluir"
                        onClick={() => handleDelete(product.id)}
                        disabled={isDeleting === product.id}
                      >
                        <Trash2 size={20} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Edit Modal */}
      {editingProduct && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Editar Produto</h2>
                <button
                  onClick={() => {
                    setEditingProduct(null);
                    setSelectedImage(null);
                    setImagePreview('');
                  }}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X size={24} />
                </button>
              </div>

              <form onSubmit={handleEditSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Solução
                    </label>
                    <select
                      required
                      value={editingProduct.solution_id}
                      onChange={(e) =>
                        setEditingProduct((prev) => prev ? ({
                          ...prev,
                          solution_id: e.target.value,
                          category_id: '' // Reset category when solution changes
                        }) : null)
                      }
                      className="w-full p-2 border rounded-lg"
                    >
                      <option value="">Selecione uma solução</option>
                      {solutions.map((solution) => (
                        <option key={solution.id} value={solution.id}>
                          {solution.title}
                        </option>
                      ))}
                    </select>
                  </div>

                  {editingProduct.solution_id && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Categoria
                      </label>
                      <select
                        required
                        value={editingProduct.category_id}
                        onChange={(e) =>
                          setEditingProduct((prev) => prev ? ({
                            ...prev,
                            category_id: e.target.value
                          }) : null)
                        }
                        className="w-full p-2 border rounded-lg"
                      >
                        <option value="">Selecione uma categoria</option>
                        {filteredCategories.map((category) => (
                          <option key={category.id} value={category.id}>
                            {category.title}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Nome do Produto
                    </label>
                    <input
                      type="text"
                      required
                      value={editingProduct.name}
                      onChange={(e) =>
                        setEditingProduct((prev) => prev ? ({
                          ...prev,
                          name: e.target.value
                        }) : null)
                      }
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Quantidade Mínima
                    </label>
                    <input
                      type="number"
                      required
                      min="1"
                      value={editingProduct.min_quantity}
                      onChange={(e) =>
                        setEditingProduct((prev) => prev ? ({
                          ...prev,
                          min_quantity: parseInt(e.target.value, 10) || 1000
                        }) : null)
                      }
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Descrição
                    </label>
                    <textarea
                      required
                      value={editingProduct.description}
                      onChange={(e) =>
                        setEditingProduct((prev) => prev ? ({
                          ...prev,
                          description: e.target.value
                        }) : null)
                      }
                      rows={4}
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Imagem do Produto
                    </label>
                    <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg">
                      <div className="space-y-1 text-center">
                        {imagePreview || editingProduct.image_url ? (
                          <div className="mb-4">
                            <img
                              src={imagePreview || editingProduct.image_url}
                              alt="Preview"
                              className="mx-auto h-32 w-32 object-cover rounded"
                            />
                          </div>
                        ) : (
                          <Image
                            className="mx-auto h-12 w-12 text-gray-400"
                            strokeWidth={1}
                          />
                        )}
                        <div className="flex text-sm text-gray-600">
                          <label className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                            <span>Upload a file</span>
                            <input
                              type="file"
                              className="sr-only"
                              accept="image/*"
                              onChange={handleImageChange}
                            />
                          </label>
                          <p className="pl-1">or drag and drop</p>
                        </div>
                        <p className="text-xs text-gray-500">
                          PNG, JPG, GIF up to 10MB
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Shipping Dimensions */}
                  <div className="md:col-span-2">
                    <h3 className="text-lg font-medium mb-4">Dimensões para Envio</h3>
                    <div className="grid md:grid-cols-4 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Peso (kg)
                        </label>
                        <input
                          type="number"
                          required
                          min="0"
                          step="0.001"
                          value={editingProduct.weight_kg}
                          onChange={(e) =>
                            setEditingProduct((prev) => prev ? ({
                              ...prev,
                              weight_kg: parseFloat(e.target.value) || 0
                            }) : null)
                          }
                          className="w-full p-2 border rounded-lg"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Altura (cm)
                        </label>
                        <input
                          type="number"
                          required
                          min="0"
                          value={editingProduct.height_cm}
                          onChange={(e) =>
                            setEditingProduct((prev) => prev ? ({
                              ...prev,
                              height_cm: parseInt(e.target.value, 10) || 0
                            }) : null)
                          }
                          className="w-full p-2 border rounded-lg"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Largura (cm)
                        </label>
                        <input
                          type="number"
                          required
                          min="0"
                          value={editingProduct.width_cm}
                          onChange={(e) =>
                            setEditingProduct((prev) => prev ? ({
                              ...prev,
                              width_cm: parseInt(e.target.value, 10) || 0
                            }) : null)
                          }
                          className="w-full p-2 border rounded-lg"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Comprimento (cm)
                        </label>
                        <input
                          type="number"
                          required
                          min="0"
                          value={editingProduct.length_cm}
                          onChange={(e) =>
                            setEditingProduct((prev) => prev ? ({
                              ...prev,
                              length_cm: parseInt(e.target.value, 10) || 0
                            }) : null)
                          }
                          className="w-full p-2 border rounded-lg"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-sm font-medium text-gray-700">
                      Medidas, Preços e Estoque
                    </label>
                    <button
                      type="button"
                      onClick={handleAddDimension}
                      className="text-sm text-blue-600 hover:text-blue-800"
                    >
                      + Adicionar Medida
                    </button>
                  </div>
                  {editingProduct.dimensions.map((dimension, index) => (
                    <div key={index} className="grid grid-cols-5 gap-4 mb-4">
                      <div>
                        <input
                          type="text"
                          placeholder="Medida"
                          required
                          value={dimension.size}
                          onChange={(e) => handleDimensionChange(index, 'size', e.target.value)}
                          className="w-full p-2 border rounded-lg"
                        />
                      </div>
                      <div>
                        <input
                          type="number"
                          placeholder="Preço"
                          required
                          min="0"
                          step="0.01"
                          value={dimension.price}
                          onChange={(e) => handleDimensionChange(index, 'price', e.target.value)}
                          className="w-full p-2 border rounded-lg"
                        />
                      </div>
                      <div>
                        <input
                          type="number"
                          placeholder="Desconto (%)"
                          min="0"
                          max="100"
                          step="0.1"
                          value={dimension.discount_percentage || 0}
                          onChange={(e) => handleDimensionChange(index, 'discount_percentage', e.target.value)}
                          className="w-full p-2 border rounded-lg"
                        />
                      </div>
                      <div>
                        <input
                          type="number"
                          placeholder="Estoque"
                          required
                          min="0"
                          value={dimension.stock}
                          onChange={(e) => handleDimensionChange(index, 'stock', e.target.value)}
                          className="w-full p-2 border rounded-lg"
                        />
                      </div>
                      <div className="flex items-center">
                        {editingProduct.dimensions.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveDimension(index)}
                            className="text-red-600 hover:text-red-800 px-2"
                          >
                            ×
                          </button>
                        )}
                        {dimension.discount_percentage > 0 && (
                          <div className="text-sm text-gray-500">
                            Preço final: R$ {(dimension.price * (1 - dimension.discount_percentage / 100)).toFixed(2)}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full btn bg-green-500 hover:bg-green-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? 'Salvando...' : 'Salvar Alterações'}
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}