/*
  # Insert solutions and categories data

  1. Solutions
    - Ribbons
    - Fitas
    - Print
    - Térmicas (Supermercados)
    - Lacre
    - Bobinas Térmicas

  2. Categories for each solution
    - Ribbons: Cera, Resina, Misto
    - Fitas: Selagem
    - Print: Automação, Etiquetas, Tag
    - Térmicas: Etiquetas Balanças, Bobinas PDV, Etiquetas Térmicas, Etiquetadora
    - Lacre: Delivery, Em Bobinas
    - Bobinas: Máquina de Cartão, Cupom Fiscal, Senha, Comanda
*/

-- Insert solutions
INSERT INTO solutions (title, description, image_url, sort_order) VALUES
  (
    'Ribbons',
    'Ribbons de alta qualidade para impressão térmica, disponíveis em diferentes composições para atender suas necessidades específicas.',
    'https://images.unsplash.com/photo-1586075010923-2dd4570fb338?auto=format&fit=crop&q=80',
    0
  ),
  (
    'Fitas',
    'Fitas adesivas profissionais para selagem e identificação, garantindo segurança e durabilidade em suas aplicações.',
    'https://images.unsplash.com/photo-1586074299757-dc655f18518c?auto=format&fit=crop&q=80',
    1
  ),
  (
    'Print',
    'Soluções completas de impressão para automação e identificação, com opções versáteis para diferentes necessidades.',
    'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80',
    2
  ),
  (
    'Térmicas',
    'Etiquetas térmicas especializadas para supermercados, oferecendo qualidade e durabilidade para identificação de produtos.',
    'https://images.unsplash.com/photo-1534723452862-4c874018d66d?auto=format&fit=crop&q=80',
    3
  ),
  (
    'Lacre',
    'Soluções de lacre para delivery e outras aplicações, garantindo a segurança e inviolabilidade dos produtos.',
    'https://images.unsplash.com/photo-1580674285054-bed31e145f59?auto=format&fit=crop&q=80',
    4
  ),
  (
    'Bobinas Térmicas',
    'Bobinas térmicas de alta qualidade para diferentes aplicações, desde PDV até comandas e senhas.',
    'https://images.unsplash.com/photo-1553413077-190dd305871c?auto=format&fit=crop&q=80',
    5
  );

-- Insert categories
INSERT INTO categories (solution_id, title, description, slug, sort_order) VALUES
  -- Ribbons categories
  (
    (SELECT id FROM solutions WHERE title = 'Ribbons'),
    'Cera',
    'Ribbons de cera para impressão térmica, ideal para aplicações gerais.',
    'ribbons-cera',
    0
  ),
  (
    (SELECT id FROM solutions WHERE title = 'Ribbons'),
    'Resina',
    'Ribbons de resina para impressão térmica, oferecendo maior durabilidade.',
    'ribbons-resina',
    1
  ),
  (
    (SELECT id FROM solutions WHERE title = 'Ribbons'),
    'Misto',
    'Ribbons mistos combinando cera e resina, equilibrando qualidade e custo.',
    'ribbons-misto',
    2
  ),

  -- Fitas categories
  (
    (SELECT id FROM solutions WHERE title = 'Fitas'),
    'Selagem',
    'Fitas especiais para selagem, garantindo segurança e inviolabilidade.',
    'fitas-selagem',
    0
  ),

  -- Print categories
  (
    (SELECT id FROM solutions WHERE title = 'Print'),
    'Automação',
    'Soluções de impressão para automação de processos.',
    'print-automacao',
    0
  ),
  (
    (SELECT id FROM solutions WHERE title = 'Print'),
    'Etiquetas',
    'Etiquetas especiais para impressão.',
    'print-etiquetas',
    1
  ),
  (
    (SELECT id FROM solutions WHERE title = 'Print'),
    'Tag',
    'Tags e identificadores para diferentes aplicações.',
    'print-tag',
    2
  ),

  -- Térmicas categories
  (
    (SELECT id FROM solutions WHERE title = 'Térmicas'),
    'Etiquetas Balanças',
    'Etiquetas térmicas específicas para balanças de supermercado.',
    'termicas-balancas',
    0
  ),
  (
    (SELECT id FROM solutions WHERE title = 'Térmicas'),
    'Bobinas PDV',
    'Bobinas térmicas para pontos de venda.',
    'termicas-pdv',
    1
  ),
  (
    (SELECT id FROM solutions WHERE title = 'Térmicas'),
    'Etiquetas Térmicas',
    'Etiquetas térmicas para diversas aplicações.',
    'termicas-etiquetas',
    2
  ),
  (
    (SELECT id FROM solutions WHERE title = 'Térmicas'),
    'Etiquetadora',
    'Soluções completas de etiquetagem térmica.',
    'termicas-etiquetadora',
    3
  ),

  -- Lacre categories
  (
    (SELECT id FROM solutions WHERE title = 'Lacre'),
    'Delivery',
    'Lacres especiais para delivery e entrega.',
    'lacre-delivery',
    0
  ),
  (
    (SELECT id FROM solutions WHERE title = 'Lacre'),
    'Em Bobinas',
    'Lacres em formato de bobina para maior praticidade.',
    'lacre-bobinas',
    1
  ),

  -- Bobinas categories
  (
    (SELECT id FROM solutions WHERE title = 'Bobinas Térmicas'),
    'Máquina de Cartão',
    'Bobinas específicas para máquinas de cartão.',
    'bobinas-cartao',
    0
  ),
  (
    (SELECT id FROM solutions WHERE title = 'Bobinas Térmicas'),
    'Cupom Fiscal',
    'Bobinas para impressão de cupom fiscal.',
    'bobinas-fiscal',
    1
  ),
  (
    (SELECT id FROM solutions WHERE title = 'Bobinas Térmicas'),
    'Senha',
    'Bobinas para sistemas de senha e atendimento.',
    'bobinas-senha',
    2
  ),
  (
    (SELECT id FROM solutions WHERE title = 'Bobinas Térmicas'),
    'Comanda',
    'Bobinas para comandas e controle.',
    'bobinas-comanda',
    3
  );