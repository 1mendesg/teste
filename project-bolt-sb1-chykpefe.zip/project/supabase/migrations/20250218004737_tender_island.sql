/*
  # Create solutions and categories tables

  1. New Tables
    - `solutions`
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text) 
      - `image_url` (text)
      - `sort_order` (integer)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `categories`
      - `id` (uuid, primary key)
      - `solution_id` (uuid, foreign key)
      - `title` (text)
      - `description` (text)
      - `slug` (text, unique)
      - `sort_order` (integer)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Add policies for public read access
    - Add policies for admin-only modifications
*/

-- Drop existing tables if they exist
DROP TABLE IF EXISTS categories CASCADE;
DROP TABLE IF EXISTS solutions CASCADE;

-- Create solutions table
CREATE TABLE solutions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  image_url text,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create categories table
CREATE TABLE categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  solution_id uuid REFERENCES solutions(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  slug text NOT NULL UNIQUE,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE solutions ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Anyone can read solutions" ON solutions;
DROP POLICY IF EXISTS "Only admin can modify solutions" ON solutions;
DROP POLICY IF EXISTS "Anyone can read categories" ON categories;
DROP POLICY IF EXISTS "Only admin can modify categories" ON categories;

-- Create policies for solutions
CREATE POLICY "Anyone can read solutions"
  ON solutions FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Only admin can modify solutions"
  ON solutions FOR ALL
  TO authenticated
  USING (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br')
  WITH CHECK (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br');

-- Create policies for categories
CREATE POLICY "Anyone can read categories"
  ON categories FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Only admin can modify categories"
  ON categories FOR ALL
  TO authenticated
  USING (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br')
  WITH CHECK (LOWER(auth.email()) = 'luciano@usualetiquetas.com.br');

-- Create indexes
CREATE INDEX solutions_sort_order_idx ON solutions(sort_order);
CREATE INDEX categories_solution_id_idx ON categories(solution_id);
CREATE INDEX categories_sort_order_idx ON categories(sort_order);
CREATE INDEX categories_slug_idx ON categories(slug);

-- Create updated_at triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_solutions_updated_at
  BEFORE UPDATE ON solutions
  FOR EACH ROW
  EXECUTE PROCEDURE update_updated_at_column();

CREATE TRIGGER update_categories_updated_at
  BEFORE UPDATE ON categories
  FOR EACH ROW
  EXECUTE PROCEDURE update_updated_at_column();