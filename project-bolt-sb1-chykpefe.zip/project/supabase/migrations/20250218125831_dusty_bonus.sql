/*
  # Add Favicon Support

  1. Changes
    - Add 'favicon' as a valid section type in site_images table
    - Add default favicon record
*/

-- Update section check constraint to include 'favicon'
ALTER TABLE site_images 
DROP CONSTRAINT IF EXISTS site_images_section_check,
ADD CONSTRAINT site_images_section_check 
CHECK (section IN ('banner', 'solution', 'custom_label', 'logo', 'about', 'favicon'));

-- Insert favicon record if it doesn't exist
INSERT INTO site_images (title, description, section)
SELECT 
  'Favicon',
  'Ícone exibido na aba do navegador',
  'favicon'
WHERE NOT EXISTS (
  SELECT 1 FROM site_images 
  WHERE title = 'Favicon' AND section = 'favicon'
);