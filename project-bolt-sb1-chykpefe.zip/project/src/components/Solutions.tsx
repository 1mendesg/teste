import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Solution {
  id: string;
  title: string;
  description: string;
  image_url: string;
  sort_order: number;
}

interface Category {
  id: string;
  solution_id: string;
  title: string;
  description: string;
  slug: string;
  sort_order: number;
}

export function Solutions() {
  const [solutions, setSolutions] = React.useState<Solution[]>([]);
  const [categories, setCategories] = React.useState<Category[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);

  React.useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [solutionsData, categoriesData] = await Promise.all([
        supabase
          .from('solutions')
          .select('*')
          .order('sort_order', { ascending: true }),
        supabase
          .from('categories')
          .select('*')
          .order('sort_order', { ascending: true })
      ]);

      if (solutionsData.data) setSolutions(solutionsData.data);
      if (categoriesData.data) setCategories(categoriesData.data);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <section id="solutions" className="py-16 bg-white">
        <div className="container">
          <div className="text-center">Carregando soluções...</div>
        </div>
      </section>
    );
  }

  return (
    <section id="solutions" className="py-16 bg-white">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Soluções
          </h2>
          <p className="text-xl text-gray-600">
            Conheça nossa linha completa de produtos para identificação.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {solutions.map((solution) => (
            <Link
              key={solution.id}
              to={`/solucoes/${solution.id}`}
              
            >
              <div className="relative h-48">
                <img
                  src={solution.image_url || 'https://images.unsplash.com/photo-1585386959984-a4155224a1ad?auto=format&fit=crop&q=80'}
                  alt={solution.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{solution.title}</h3>
                <p className="text-gray-600 mb-4">{solution.description}</p>
                {categories.some(c => c.solution_id === solution.id) && (
                  <div className="flex items-center text-[--primary] font-semibold group-hover:text-[--primary-dark] transition-colors">
                    <span>Ver Categorias</span>
                    <ArrowRight className="ml-2 transition-transform group-hover:translate-x-1" size={20} />
                  </div>
                )}
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}