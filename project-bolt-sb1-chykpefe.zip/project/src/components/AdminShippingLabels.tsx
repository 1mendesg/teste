import React from 'react';
import { Download } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { downloadShippingLabel, purchaseShippingLabel } from '../lib/melhorEnvio';

interface ShippingLabel {
  id: string;
  order_id: string;
  melhor_envio_id: string;
  carrier: string;
  tracking_code: string;
  label_url: string;
  status: string;
  shipping_cost: number;
  created_at: string;
}

export function AdminShippingLabels() {
  const [labels, setLabels] = React.useState<ShippingLabel[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [error, setError] = React.useState('');
  const [isProcessing, setIsProcessing] = React.useState<string | null>(null);

  React.useEffect(() => {
    loadLabels();
  }, []);

  const loadLabels = async () => {
    try {
      const { data, error } = await supabase
        .from('shipping_labels')
        .select(`
          *,
          order:orders(*)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setLabels(data || []);
    } catch (err) {
      console.error('Error loading shipping labels:', err);
      setError('Error loading shipping labels');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownload = async (labelId: string) => {
    try {
      setIsProcessing(labelId);
      const pdfUrl = await downloadShippingLabel(labelId);
      window.open(pdfUrl, '_blank');
    } catch (err) {
      console.error('Error downloading label:', err);
      setError('Error downloading shipping label');
    } finally {
      setIsProcessing(null);
    }
  };

  if (isLoading) {
    return <div>Loading shipping labels...</div>;
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Shipping Labels</h2>

      {error && (
        <div className="p-4 bg-red-50 text-red-700 rounded-lg">
          {error}
        </div>
      )}

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Order ID
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Carrier
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Tracking Code
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Cost
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Created At
              </th>
              <th className="px-6 py-3"></th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {labels.map((label) => (
              <tr key={label.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {label.order_id.slice(0, 8)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {label.carrier}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {label.tracking_code}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                    label.status === 'pending' 
                      ? 'bg-yellow-100 text-yellow-800'
                      : label.status === 'generated'
                      ? 'bg-green-100 text-green-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {label.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  R$ {label.shipping_cost.toFixed(2)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {new Date(label.created_at).toLocaleDateString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  {label.label_url && (
                    <button
                      onClick={() => handleDownload(label.melhor_envio_id)}
                      disabled={isProcessing === label.id}
                      className="text-blue-600 hover:text-blue-900 disabled:opacity-50"
                    >
                      <Download className="w-5 h-5" />
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}