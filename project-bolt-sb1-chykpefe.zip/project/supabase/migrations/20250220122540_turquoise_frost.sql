-- Add status and payment_status columns to simple_orders
ALTER TABLE simple_orders
ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS payment_status text NOT NULL DEFAULT 'pending';

-- Add check constraints for valid statuses
ALTER TABLE simple_orders
ADD CONSTRAINT valid_status CHECK (
  status IN ('pending', 'processing', 'completed', 'cancelled')
),
ADD CONSTRAINT valid_payment_status CHECK (
  payment_status IN ('pending', 'paid')
);

-- Update existing orders to have default statuses if needed
UPDATE simple_orders
SET 
  status = 'pending',
  payment_status = 'pending'
WHERE status IS NULL OR payment_status IS NULL;

-- Create indexes for the new columns
CREATE INDEX IF NOT EXISTS simple_orders_status_idx ON simple_orders(status);
CREATE INDEX IF NOT EXISTS simple_orders_payment_status_idx ON simple_orders(payment_status);