import { supabase } from './supabase';

interface ShippingProduct {
  weight_kg: number;
  quantity: number;
}

interface ShippingOption {
  id: string;
  name: string;
  price: number;
  delivery_time: number;
  company: {
    name: string;
  };
  address?: string;
}

export async function calculateShipping(
  products: ShippingProduct[],
  toZipCode: string
): Promise<ShippingOption[]> {
  try {
    // Always include store pickup option
    const options: ShippingOption[] = [
      {
        id: 'pickup',
        name: 'Retirar na Loja',
        price: 0,
        delivery_time: 1,
        company: {
          name: 'Retirada'
        },
        address: 'Av. Ver. Toaldo Túlio, 1735 - Santa Felicidade, Curitiba - PR, 82320-010'
      }
    ];

    // Get shipping config
    const { data: config } = await supabase
      .from('shipping_config')
      .select('*')
      .single();

    if (!config) {
      throw new Error('Configuração de frete não encontrada');
    }

    // Get CEP ranges
    const { data: ranges } = await supabase
      .from('shipping_cep_ranges')
      .select('*')
      .order('base_price', { ascending: true });

    if (!ranges || ranges.length === 0) {
      throw new Error('Faixas de CEP não configuradas');
    }

    // Find matching CEP range
    const numericCep = parseInt(toZipCode);
    const range = ranges.find(r => {
      const startCep = parseInt(r.start_cep);
      const endCep = parseInt(r.end_cep);
      return numericCep >= startCep && numericCep <= endCep;
    });

    if (!range) {
      return options; // Return only store pickup if CEP is not in any range
    }

    // Calculate total weight
    const totalWeight = products.reduce((sum, p) => sum + (p.weight_kg * p.quantity), 0);

    // Calculate base shipping price with minimum price from range
    const basePrice = Math.max(range.base_price, config.min_weight_kg * range.base_price);
    const weightMultiplier = range.weight_multiplier;
    const weightPrice = totalWeight > config.min_weight_kg 
      ? (totalWeight - config.min_weight_kg) * weightMultiplier 
      : 0;
    const finalBasePrice = basePrice + weightPrice;

    // Add shipping options
    options.push(
      {
        id: 'pac',
        name: 'PAC',
        price: finalBasePrice,
        delivery_time: 10,
        company: {
          name: 'PAC'
        }
      },
      {
        id: 'express',
        name: 'Usuality Expresso',
        price: finalBasePrice + config.express_surcharge,
        delivery_time: 3,
        company: {
          name: 'Usuality Expresso'
        }
      }
    );

    return options;
  } catch (error: any) {
    console.error('Error calculating shipping:', error);
    throw new Error(error.message || 'Erro ao calcular o frete');
  }
}