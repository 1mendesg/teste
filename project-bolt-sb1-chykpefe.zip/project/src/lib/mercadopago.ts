import { CartItem } from './cart';
import { supabase } from './supabase';

interface MercadoPagoPreference {
  items: Array<{
    title: string;
    unit_price: number;
    quantity: number;
    currency_id: string;
    picture_url?: string;
  }>;
  back_urls: {
    success: string;
    failure: string;
    pending: string;
  };
  auto_return: string;
  external_reference: string;
}

export async function createPreference(items: CartItem[], shippingCost: number = 0): Promise<string> {
  try {
    // Create order in Supabase first
    const user = (await supabase.auth.getUser()).data.user;
    if (!user) throw new Error('User not authenticated');

    const totalPrice = items.reduce((sum, item) => sum + item.price * item.quantity, 0) + shippingCost;

    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert({
        user_id: user.id,
        status: 'pending',
        payment_status: 'pending',
        total_price: totalPrice,
        items: items
      })
      .select()
      .single();

    if (orderError) throw orderError;

    // Create Mercado Pago items array including shipping
    const mpItems = [
      ...items.map(item => ({
        title: `${item.name} - ${item.size}`,
        unit_price: Number(item.price),
        quantity: item.quantity,
        currency_id: 'BRL',
        picture_url: item.image_url
      }))
    ];

    // Add shipping as a separate item if there's a shipping cost
    if (shippingCost > 0) {
      mpItems.push({
        title: 'Frete',
        unit_price: Number(shippingCost),
        quantity: 1,
        currency_id: 'BRL'
      });
    }

    const preference: MercadoPagoPreference = {
      items: mpItems,
      back_urls: {
        success: `${window.location.origin}/success`,
        failure: `${window.location.origin}/cart`,
        pending: `${window.location.origin}/cart`
      },
      auto_return: 'approved',
      external_reference: order.id
    };

    const response = await fetch('https://api.mercadopago.com/checkout/preferences', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${import.meta.env.VITE_MERCADOPAGO_ACCESS_TOKEN}`
      },
      body: JSON.stringify(preference),
    });

    if (!response.ok) {
      throw new Error('Failed to create preference');
    }

    const data = await response.json();
    return data.init_point;
  } catch (error) {
    console.error('Error creating Mercado Pago preference:', error);
    throw error;
  }
}